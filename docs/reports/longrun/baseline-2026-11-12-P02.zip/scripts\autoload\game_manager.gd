extends Node
## 全局状态：游戏流程、控制权、计时、调试数据。
## 控制权与角色状态由 race 场景每帧写回，这里只保存可观察值。

const Tuning = preload("res://scripts/systems/tuning.gd")
const LevelDataScript = preload("res://scripts/systems/level_data.gd")

enum GameState { MENU, RUNNING, PAUSED, RESULT }

signal accident(reason: String)
signal pickup_success
signal rescue_done
signal hint(text: String)
signal center_message(text: String, color: Color)
## 干净通过 / BRO PASS 的短反馈，和“首次介绍”分开，避免重复教学。
signal feedback(text: String, kind: String)
signal prompt(text: String)
## BRO METER 三格共享事故槽：每涨一格、满格各发一次。
signal bro_meter_changed(slots: int)
signal bro_meter_full

const MENU_SCENE := "res://scenes/menu.tscn"
const RACE_SCENE := "res://scenes/race.tscn"
const RESULT_SCENE := "res://scenes/result.tscn"
const BEST_PATH := "user://best.json"
## 分数表改版：旧档的 best_score 用的是另一套计分，和新表不可比。
## 只丢弃最高分，最佳时间/事故/连胜继续保留。
const SCORE_MODEL := 2

var state: GameState = GameState.MENU
var current_control: String = "rabbit"
var has_shifted: bool = false
var shift_count: int = 0
var race_time: float = 0.0
var rabbit_state: String = "RIDING"
var turtle_state: String = "CRUISING"
var mount_state: String = "RIDING"
var oxygen: float = Tuning.OXYGEN_MAX
var oxygen_phase: String = "SAFE"
var turtle_speed: float = 220.0
var accident_state: String = "NONE"
var accident_count: int = 0
var pickup_count: int = 0
var slide_progress: float = 0.0
var pickup_window: bool = false
var rabbit_phase: String = "RIDING"
var turtle_phase: String = "CRUISING"
var combo: int = 0
var combo_max: int = 0
var showtime_count: int = 0
var showtime_active: bool = false

# ---- 阶段 3：区域、评分、结算与个人纪录。 ----
var zone: int = 1
var zone_name_text: String = "SUNNY COAST"
var zones_visited: Dictionary = {1: true}
var rabbit_casualties: int = 0
var turtle_failures: int = 0
var perfect_cooperation: int = 0
var perfect_streak: int = 0
var best_streak: int = 0
var total_score: int = 0
var grade: String = ""
var grade_name: String = ""
var finish_time: float = 0.0
var finished: bool = false
var new_best_time := false
var new_best_score := false
var new_best_streak := false

var best_time: float = -1.0
var best_accidents: int = -1
var best_score: int = -1
var best_streak_record: int = 0

# ---- 阶段 4：BRO METER（三格共享事故槽）与指令里的分数表。 ----
const BRO_METER_SLOTS := 3
var bro_meter: int = 0
var bro_meter_max: int = 0
var bro_joint_pending := false
var joint_accident_count: int = 0
var combo_dive_count: int = 0
var combo_ollie_count: int = 0
var clean_pass_count: int = 0
## 逐笔分数（reason/points），给测量与结算核对用；只保留最近若干笔。
var score_log: Array = []


func _ready() -> void:
	_bind_inputs()
	_load_best()


func _process(delta: float) -> void:
	if state == GameState.RUNNING:
		race_time += delta


func _bind_inputs() -> void:
	var keys := {
		"shift": [KEY_SHIFT],
		"boost": [KEY_RIGHT],
		"pop": [KEY_SPACE],
		"up": [KEY_UP],
		"down": [KEY_DOWN],
		"left": [KEY_LEFT],
		"right": [KEY_RIGHT],
		"pause": [KEY_ESCAPE],
		"restart": [KEY_R],
		"confirm": [KEY_ENTER],
		"menu": [KEY_M],
	}
	for action in keys.keys():
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key in keys[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("shift"):
		toggle_control()
	elif event.is_action_pressed("pause"):
		toggle_pause()
	elif event.is_action_pressed("restart"):
		# 结算界面也承诺 R 重开；阶段 3 的第二次通关就走这条路。
		if state == GameState.RUNNING or state == GameState.PAUSED \
				or state == GameState.RESULT:
			start_race()
	elif event.is_action_pressed("menu"):
		if state == GameState.PAUSED or state == GameState.RESULT:
			go_to_menu()


func start_race() -> void:
	_reset_run()
	state = GameState.RUNNING
	get_tree().change_scene_to_file(RACE_SCENE)


func go_to_menu() -> void:
	state = GameState.MENU
	get_tree().change_scene_to_file(MENU_SCENE)


func finish_race() -> void:
	state = GameState.RESULT
	get_tree().change_scene_to_file(RESULT_SCENE)


func toggle_control() -> void:
	if state != GameState.RUNNING:
		return
	# 主动救援是唯一允许在事故中换人的状态：玩家必须切到乌龟把兔子接上来。
	if accident_state != "NONE" and accident_state != "RABBIT_WATER" \
			and accident_state != "RABBIT_AIR":
		return
	# Showtime 期间 SHIFT 是“中断表演”，由 race 处理，不能普通换人。
	if showtime_active:
		return
	current_control = "rabbit" if current_control == "turtle" else "turtle"
	has_shifted = true
	shift_count += 1


func set_control(who: String) -> void:
	if who == current_control:
		return
	current_control = who
	has_shifted = true


func toggle_pause() -> void:
	if state == GameState.RUNNING:
		state = GameState.PAUSED
	elif state == GameState.PAUSED:
		state = GameState.RUNNING
	# 主菜单的 ESC 由菜单自己处理（弹退出确认），这里不直接退出游戏。


func _reset_run() -> void:
	current_control = "rabbit"
	has_shifted = false
	shift_count = 0
	race_time = 0.0
	rabbit_state = "RIDING"
	turtle_state = "CRUISING"
	mount_state = "RIDING"
	oxygen = Tuning.OXYGEN_MAX
	oxygen_phase = "SAFE"
	turtle_speed = 220.0
	accident_state = "NONE"
	accident_count = 0
	pickup_count = 0
	slide_progress = 0.0
	pickup_window = false
	rabbit_phase = "RIDING"
	turtle_phase = "CRUISING"
	combo = 0
	combo_max = 0
	showtime_count = 0
	showtime_active = false
	zone = 1
	zone_name_text = "SUNNY COAST"
	zones_visited = {1: true}
	rabbit_casualties = 0
	turtle_failures = 0
	perfect_cooperation = 0
	perfect_streak = 0
	best_streak = 0
	total_score = 0
	grade = ""
	grade_name = ""
	finish_time = 0.0
	finished = false
	new_best_time = false
	new_best_score = false
	new_best_streak = false
	bro_meter = 0
	bro_meter_max = 0
	bro_joint_pending = false
	joint_accident_count = 0
	combo_dive_count = 0
	combo_ollie_count = 0
	clean_pass_count = 0
	score_log.clear()


func state_name() -> String:
	return GameState.keys()[state]


# ---- 阶段 3：事件记账。 ----

func note_zone(id: int, name: String) -> void:
	zone = id
	zone_name_text = name
	zones_visited[id] = true


## 统一的失误记账（Phase G）：所有“有效失误”只走这一条路——
## 兔子撞障碍、乌龟撞浪、落水/翻壳等事故都记 1 格 BRO METER、扣 100 分。
## BRO METER 是唯一的持续惩罚；daze_time 只做短硬直，不许再记第二笔。
func note_mistake(reason: String) -> void:
	accident_count += 1
	perfect_streak = 0
	add_score(-100, "mistake:" + reason)
	bro_meter = mini(bro_meter + 1, BRO_METER_SLOTS)
	bro_meter_max = maxi(bro_meter_max, bro_meter)
	bro_meter_changed.emit(bro_meter)
	if bro_meter >= BRO_METER_SLOTS and not bro_joint_pending:
		bro_joint_pending = true
		joint_accident_count += 1
		add_score(-200, "joint")
		bro_meter_full.emit()


func note_accident(reason: String) -> void:
	if reason in ["RABBIT_SLIP", "RABBIT_WATER", "RABBIT_AIR", "OXYGEN_OUT"]:
		rabbit_casualties += 1
	elif reason == "TURTLE_REEF":
		turtle_failures += 1
	note_mistake(reason)


## 联合惩罚演出结束时才清空：演出期间三格保持满，玩家看得到“这是第三格”。
func clear_bro_meter() -> void:
	bro_meter = 0
	bro_joint_pending = false
	bro_meter_changed.emit(bro_meter)


# ---- 阶段 4：指令里的分数表（同一次动作只记一笔）。 ----

func add_score(points: int, reason: String) -> void:
	total_score = maxi(total_score + points, 0)
	score_log.append({"reason": reason, "points": points})
	if score_log.size() > 240:
		score_log.pop_front()


func note_clean_pass() -> void:
	clean_pass_count += 1
	add_score(100, "clean")
	perfect_cooperation += 1
	perfect_streak += 1
	best_streak = maxi(best_streak, perfect_streak)


## 精准动作（跳/趴/潜/跃）或两种连招。连招整段完成才调用，不给“半套”分。
func note_precise_pass(kind: String) -> void:
	clean_pass_count += 1
	perfect_cooperation += 1
	perfect_streak += 1
	best_streak = maxi(best_streak, perfect_streak)
	match kind:
		"FLOATING_LOG":
			combo_dive_count += 1
			add_score(250, "bro_dive")
		"HIGH_WALL":
			combo_ollie_count += 1
			add_score(300, "bro_ollie")
		_:
			add_score(150, "precise:" + kind)


func note_showtime() -> void:
	# Showtime 结束不清完美连胜；只有事故才清。
	pass


func finalize_run() -> void:
	if finished:
		return
	finished = true
	finish_time = race_time
	# STAGE 4 起分数按动作逐笔累计（见 add_score / note_precise_pass），
	# 冲线时不再按时间/连击重算，等待或拖延不会加一分。
	grade = grade_for_score(total_score)
	grade_name = grade_title(grade)
	_update_best()
	_save_best()


## 兼容旧调用：分数已经是逐笔累计值。
func compute_score() -> int:
	return total_score


## 满编 55 组全精准 = 44×150 + 3×300 + 8×250 = 9500。
func grade_for_score(score: int) -> String:
	if score >= 8000:
		return "S"
	if score >= 6500:
		return "A"
	if score >= 5000:
		return "B"
	if score >= 3000:
		return "C"
	return "D"


func grade_title(g: String) -> String:
	# 显示文案统一走 Locale；这里只决定等级。
	return Locale.grade_title(g)


func _update_best() -> void:
	new_best_time = best_time < 0.0 or finish_time < best_time
	new_best_score = total_score > best_score
	new_best_streak = best_streak > best_streak_record
	if new_best_time:
		best_time = finish_time
	# GDD 12.4 的计分按全部事故计罚；最好纪录必须用同一口径，
	# 否则硬直（RABBIT_STUN）不进 best_accidents，结算里的“最佳事故数”会偏乐观。
	var accidents := accident_count
	if best_accidents < 0 or accidents < best_accidents:
		best_accidents = accidents
	if new_best_score:
		best_score = total_score
	if new_best_streak:
		best_streak_record = best_streak


func _load_best() -> void:
	if not FileAccess.file_exists(BEST_PATH):
		return
	var file := FileAccess.open(BEST_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	best_time = float(parsed.get("best_time", -1.0))
	best_accidents = int(parsed.get("best_accidents", -1))
	best_score = int(parsed.get("best_score", -1))
	best_streak_record = int(parsed.get("best_streak", 0))
	# 没写 model 的档就是旧计分；最高分作废，别的纪录保留。
	if int(parsed.get("score_model", 1)) != SCORE_MODEL:
		best_score = -1


func _save_best() -> void:
	var file := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify({
		"score_model": SCORE_MODEL,
		"best_time": best_time,
		"best_accidents": best_accidents,
		"best_score": best_score,
		"best_streak": best_streak_record,
	}))
	file.close()


func best_path_absolute() -> String:
	return ProjectSettings.globalize_path(BEST_PATH)
