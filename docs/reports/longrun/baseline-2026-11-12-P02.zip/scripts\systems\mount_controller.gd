extends Node
## 骑乘关系：离壳、接人判定、救援计时。
## 接人窗口按制作人反馈放宽：横向 120 px、纵向 -60～90，命中后直接吸附。

const Tuning = preload("res://scripts/systems/tuning.gd")

var state := "RIDING"
var rescue_timer := 0.0


func reset() -> void:
	state = "RIDING"
	rescue_timer = 0.0


func mark_airborne() -> void:
	state = "AIRBORNE"


func mark_riding() -> void:
	state = "RIDING"
	rescue_timer = 0.0


func mark_rescuing(seconds: float) -> void:
	state = "RESCUING"
	rescue_timer = seconds


## 主动救援：兔子在水里，玩家必须把乌龟潜到它下面；不是自动倒计时放回。
func mark_rescue_active(seconds: float) -> void:
	state = "RESCUE_ACTIVE"
	rescue_timer = seconds


func tick_rescue_active(delta: float) -> bool:
	if state != "RESCUE_ACTIVE":
		return false
	rescue_timer = maxf(rescue_timer - delta, 0.0)
	return rescue_timer <= 0.0


## 救援接住的几何与普通接人一致：横向 120 px，纵向 -60～90（相对壳上落点）。
## 兔子在水里 460；巡航落点 276 -> 差 184（够不着），满潜落点 426 -> 差 34（够得着）。
func can_rescue_catch(rabbit_pos: Vector2, mount_point: Vector2) -> bool:
	if state != "RESCUE_ACTIVE":
		return false
	var dx := absf(rabbit_pos.x - mount_point.x)
	var dy := rabbit_pos.y - mount_point.y
	return dx <= Tuning.PICKUP_DX \
		and dy >= Tuning.PICKUP_DY_MIN and dy <= Tuning.PICKUP_DY_MAX


## 方案 2 原型：空中救援。兔子从上方落下，乌龟必须正在跃起，壳顶才有高度。
func mark_rescue_air(seconds: float) -> void:
	state = "RESCUE_AIR"
	rescue_timer = seconds


func tick_rescue_air(delta: float) -> bool:
	if state != "RESCUE_AIR":
		return false
	rescue_timer = maxf(rescue_timer - delta, 0.0)
	return rescue_timer <= 0.0


func can_rescue_air_catch(rabbit_pos: Vector2, mount_point: Vector2,
		turtle_leaping: bool) -> bool:
	if state != "RESCUE_AIR" or not turtle_leaping:
		return false
	var dx := absf(rabbit_pos.x - mount_point.x)
	var dy := rabbit_pos.y - mount_point.y
	return dx <= Tuning.PICKUP_DX \
		and dy >= Tuning.PICKUP_DY_MIN and dy <= Tuning.PICKUP_DY_MAX


func can_pickup(rabbit_pos: Vector2, rabbit_vel_y: float, mount_point: Vector2,
		turtle_at_surface: bool, turtle_rising: bool = false) -> bool:
	if state != "AIRBORNE":
		return false
	if rabbit_vel_y < 0.0 or not turtle_at_surface:
		return false
	var dx := absf(rabbit_pos.x - mount_point.x)
	var dy := rabbit_pos.y - mount_point.y
	# 接住正在上浮的壳时纵向窗口放宽（BRO DIVE）；巡航中的壳保持 -60。
	var dy_min := Tuning.PICKUP_DY_MIN_RISING if turtle_rising else Tuning.PICKUP_DY_MIN
	return dx <= Tuning.PICKUP_DX \
		and dy >= dy_min and dy <= Tuning.PICKUP_DY_MAX


func tick_rescue(delta: float) -> bool:
	if state != "RESCUING":
		return false
	rescue_timer -= delta
	return rescue_timer <= 0.0
