extends Node2D
## 阶段 3：一条 66000 px 的完整赛道，分三个区域连续比赛。
## 氧气三档、分阶段失控、六类障碍、事故分级、Brotherhood 连击与 Showtime。
## 赛道数据在 level_data.gd；障碍判定全部走矩形，H 键可显示真实碰撞框。

const Tuning = preload("res://scripts/systems/tuning.gd")
const LevelDataScript = preload("res://scripts/systems/level_data.gd")
const TurtleScript = preload("res://scripts/actors/turtle_controller.gd")
const RabbitScript = preload("res://scripts/actors/rabbit_controller.gd")
const MountScript = preload("res://scripts/systems/mount_controller.gd")
const HUDScript = preload("res://scripts/ui/hud.gd")
const PauseMenuScript = preload("res://scripts/ui/pause_menu.gd")

const SURFACE_Y := 300.0
const WORLD_END := LevelDataScript.WORLD_END
const HAZARD_WARN := 270.0
## 表演需要的空档：1.8 s 表演 + 1.0 s 结束宽限 + 换人/起跳提前量，按 260 px/s 取约 900 px。
const SHOWTIME_CLEAR := 900.0
## 下沉门没有手动潜深，换人的时机就是全部：预警牌放在换人的最佳位置
## （灰盒实测 180–220 px 可过，200 px 余量最大），而不是通用 270 px。
const GATE_WARN := 200.0
const FINISH_DELAY := 1.6

var hazard_groups: Array = []
var boost_lanes: Array = []
## 赛道终点：正式赛道 66000；原型段只有 8600。
var world_end := WORLD_END
var current_zone: Dictionary = LevelDataScript.ZONES[0]
var lesson_seen := {}
var boost_lesson_seen := false
var finishing := false
var finish_timer := 0.0
const BOOST_LANE_SPEED := 380.0

var turtle
var rabbit
var mount
var camera: Camera2D
var hud
var hazard_cooldown := 0.0
var turtle_repair := 0.0
var turtle_grace := 0.0
var rabbit_grace := 0.0
var rabbit_stun := 0.0
var emergency_timer := 0.0
var test_disable_hazards := false
var test_no_finish := false
var show_hitboxes := false
## F3 调试层：障碍 ID/类型/预期动作、判定框、触发距离、危险深度线。
## 关闭后世界里的开发文字、辅助线和碰撞框全部消失。
var debug_mode := false
var combo := 0
var combo_max := 0
var passed_groups := {}
var entered_groups := {}
var hit_groups := {}
## STAGE 4：通过某个障碍时“实际用了哪个动作”。只在障碍横穿带里采样，
## 避免提前很久的乱跳被算成精准动作。通过时据此给 150/250/300 或 100。
var group_actions := {}
## BRO METER 满格后的联合惩罚演出：固定在事故恢复完成后播。
var joint_show_t := 0.0
var _joint_turtle_y := 0.0
const JOINT_SHOW_TIME := 1.4
const ACT_BAND := 40.0
var showtime_active := false
var showtime_t := 0.0
var showtime_prev_control := "rabbit"
## Phase F：主动救援原型。--rescue-proto 进入单场景循环，正常赛道不受影响。
var rescue_proto_mode := false
var rescue_proto_air_mode := false
var rescue_proto_reset_t := 0.0
## 供自动探针读取："" / "caught" / "missed"。
var rescue_last_result := ""
var _oxygen_phase := "SAFE"
## 障碍尾端的自动上浮闸：一旦在尾端窗口内触发，就锁到真正回到巡航水深为止。
## 只锁 260 px 的固定距离不够——从满潜深度带着下沉惯性上浮要将近 1 s，
## 窗口一过玩家还按着 ↓，壳又重新往下走，等于“自动上浮”没兑现。
var _debug_overlay: CanvasLayer
## 事故演出的闪白计时与演出时钟（0.15 s 一闪，短促不挡操作）。
var accident_flash := 0.0
var _accident_t := 0.0


func _ready() -> void:
	# --proto 进入“障碍空间原型段”：五类障碍各一组，用来验组合漂浮物。
	var args := OS.get_cmdline_user_args()
	if "--rescue-proto" in args or "--rescue-proto-air" in args:
		setup_rescue_proto()
	elif "--proto" in args:
		setup_proto()
	else:
		load_level(LevelDataScript.groups(), LevelDataScript.boost_lanes())
	current_zone = LevelDataScript.zone_by_id(1)
	GameManager.note_zone(1, current_zone["name"])

	turtle = TurtleScript.new()
	turtle.name = "Turtle"
	add_child(turtle)
	rabbit = RabbitScript.new()
	rabbit.name = "Rabbit"
	add_child(rabbit)
	mount = MountScript.new()
	mount.name = "MountController"
	add_child(mount)

	camera = Camera2D.new()
	camera.position_smoothing_enabled = false
	add_child(camera)
	camera.make_current()

	var hud_layer := CanvasLayer.new()
	hud_layer.name = "HUDLayer"
	add_child(hud_layer)
	hud = HUDScript.new()
	hud.name = "HUD"
	hud_layer.add_child(hud)
	hud.race = self

	# 暂停菜单用原生控件：继续 / 重新开始 / 返回主菜单，鼠标和键盘都能操作。
	var pause_layer := CanvasLayer.new()
	pause_layer.name = "PauseLayer"
	add_child(pause_layer)
	var pause_menu := PauseMenuScript.new()
	pause_menu.name = "PauseMenu"
	pause_layer.add_child(pause_menu)

	_debug_overlay = get_node_or_null("DebugOverlay")
	if _debug_overlay != null:
		_debug_overlay.visible = false

	GameManager.current_control = "rabbit"
	GameManager.has_shifted = false
	# 冲浪板模型开局就停在巡航水深（壳体略低于水面），不要先在水线上再浮上来。
	turtle.reset(Vector2(400.0, surface_ref()))
	rabbit.reset()
	rabbit.attach(turtle.get_mount_point())
	mount.reset()
	_update_camera()
	queue_redraw()

	# 窗口化真实按键测试：先让窗口稳定 1.5 s 再开始救援，避免 OS 按键
	# 在引擎还没准备好接收输入时被丢掉。只影响 --capture-rescue 运行。
	if "--capture-rescue" in args:
		await get_tree().create_timer(1.5).timeout

	if "--rescue-proto" in args:
		start_rescue_proto(false)
	elif "--rescue-proto-air" in args:
		start_rescue_proto(true)

	if "--capture-stage2" in args or "--capture-accident" in args \
			or "--capture-showtime" in args or "--capture-boost" in args \
			or "--capture-race" in args or "--capture-pause" in args \
			or "--capture-imbalance" in args or "--capture-fall" in args \
			or "--capture-flip" in args or "--capture-leap" in args \
			or "--capture-debug" in args or "--capture-standby" in args \
			or "--capture-proto" in args or "--capture-penalty" in args \
			or "--capture-shark" in args or "--capture-dive-block" in args:
		GameManager.state = GameManager.GameState.RUNNING
	if "--capture-stage2" in args:
		_capture_after(1.0, "stage2_hud.png")
	if "--capture-race" in args:
		_capture_after(1.0, _arg_after(args, "--capture-race", "stage4_race.png"))
	if "--capture-leap" in args:
		_capture_leap(_arg_after(args, "--capture-leap", "stage4_leap.png"))
	if "--capture-debug" in args:
		_capture_debug(_arg_after(args, "--capture-debug", "stage4_debug.png"))
	if "--capture-shark" in args:
		_capture_shark(_arg_after(args, "--capture-shark", "phase-h_shark.png"))
	if "--capture-dive-block" in args:
		_capture_dive_block(_arg_after(args, "--capture-dive-block", "rock"))
	if "--capture-proto" in args:
		_capture_proto(_arg_after(args, "--capture-proto", "proto"))
	if "--capture-penalty" in args:
		_capture_penalty(_arg_after(args, "--capture-penalty", "phase-g"))
	if "--capture-rescue" in args:
		_capture_rescue(_arg_after(args, "--capture-rescue", "rescue_proto.png"))
	if "--capture-standby" in args:
		_capture_standby(_arg_after(args, "--capture-standby", "stage4_standby.png"))
	if "--capture-pause" in args:
		_capture_pause(_arg_after(args, "--capture-pause", "stage4_pause.png"))
	if "--capture-accident" in args:
		_capture_accident()
	if "--capture-imbalance" in args:
		_capture_imbalance()
	if "--capture-fall" in args:
		_capture_fall(_arg_after(args, "--capture-fall", "stage4_fall.png"))
	if "--capture-flip" in args:
		_capture_flip(_arg_after(args, "--capture-flip", "stage4_flip.png"))
	if "--capture-showtime" in args:
		_capture_showtime()
	if "--capture-boost" in args:
		_capture_boost()


## 装载赛道数据。冲浪板模型把整层障碍沿 y 下移同样的量：
## 只动深度，不动 x，所以组位置、连击、密度和旧审计完全一致。
func load_level(groups: Array, lanes: Array) -> void:
	hazard_groups = groups
	boost_lanes = lanes
	group_actions.clear()
	if not Tuning.SURFBOARD_PHYSICS:
		return
	var dy: float = Tuning.WORLD_Y_SHIFT
	for i in hazard_groups.size():
		var group: Dictionary = hazard_groups[i]
		var rects := []
		for r in group["rects"]:
			var rect: Rect2 = r
			rects.append(Rect2(rect.position + Vector2(0.0, dy), rect.size))
		group["rects"] = rects
	for i in boost_lanes.size():
		var lane: Rect2 = boost_lanes[i]
		boost_lanes[i] = Rect2(lane.position + Vector2(0.0, dy), lane.size)


## 角色的“基准水面”：旧模型是 300，冲浪板模型是巡航水深。
func surface_ref() -> float:
	return Tuning.NEUTRAL_DEPTH if Tuning.SURFBOARD_PHYSICS else SURFACE_Y


## 独立原型段：只有五类障碍，没有加速带，终点提前到 8600。
## 可重复调用（自检/截图会先 _ready 再切过来），load_level 每次都重新装一份数据。
func setup_proto() -> void:
	hazard_groups = []
	boost_lanes = []
	load_level(LevelDataScript.proto_groups(), [])
	world_end = LevelDataScript.PROTO_END


## Phase F：主动救援单场景。没有障碍，只有“兔子在水里、乌龟去接”的一段。
func setup_rescue_proto() -> void:
	hazard_groups = []
	boost_lanes = []
	world_end = 999999.0
	test_no_finish = true


## 供 --rescue-proto 和自动探针调用：把场景重置到“兔子刚落水/刚被抛起”的瞬间。
func start_rescue_proto(air: bool = false) -> void:
	rescue_proto_mode = true
	rescue_proto_air_mode = air
	test_no_finish = true
	GameManager.state = GameManager.GameState.RUNNING
	_arm_rescue_proto(air)


func _arm_rescue_proto(air: bool = false) -> void:
	rescue_proto_reset_t = 0.0
	rescue_last_result = ""
	Input.action_release("up")
	Input.action_release("down")
	Input.action_release("shift")
	GameManager.clear_bro_meter()
	GameManager.accident_state = "NONE"
	GameManager.current_control = "turtle"
	GameManager.has_shifted = true
	GameManager.oxygen = Tuning.OXYGEN_MAX
	GameManager.pickup_window = false
	GameManager.accident_count = 0
	GameManager.total_score = 0
	GameManager.score_log.clear()
	hazard_cooldown = 0.0
	rabbit_grace = 0.0
	rabbit_stun = 0.0
	emergency_timer = 0.0
	turtle_repair = 0.0
	turtle_grace = 0.0
	joint_show_t = 0.0
	showtime_active = false
	GameManager.showtime_active = false
	hit_groups.clear()
	passed_groups.clear()
	entered_groups.clear()
	turtle.reset(Vector2(400.0, Tuning.NEUTRAL_DEPTH))
	turtle.speed = 220.0
	turtle.base_speed = 220.0
	rabbit.reset()
	rabbit.attach(turtle.get_mount_point())
	mount.reset()
	mount.mark_riding()
	_update_camera()
	_trigger_accident("RABBIT_AIR" if air else "RABBIT_WATER")
	queue_redraw()



func _physics_process(delta: float) -> void:
	if GameManager.state != GameManager.GameState.RUNNING:
		_update_camera()
		queue_redraw()
		return


	# 终点演出：停止判定，让乌龟自己滑过线，短暂停留后进结算。
	if finishing:
		finish_timer -= delta
		turtle.tick(delta, false, false, 0.0, true, Tuning.BOOST_SPEED)
		rabbit.attach(turtle.get_mount_point())
		_update_camera()
		queue_redraw()
		if finish_timer <= 0.0:
			GameManager.finish_race()
		return

	_update_zone()
	turtle.base_speed = current_zone["base_speed"]

	hazard_cooldown = maxf(hazard_cooldown - delta, 0.0)
	accident_flash = maxf(accident_flash - delta, 0.0)
	if GameManager.accident_state != "NONE":
		_accident_t += delta
	else:
		_accident_t = 0.0
	turtle_grace = maxf(turtle_grace - delta, 0.0)
	rabbit_grace = maxf(rabbit_grace - delta, 0.0)
	_tick_recovery(delta)

	# 救援原型：一次成功/失败演完，停 1.6–2.2 s 再自动重开同一段，方便反复试。
	if rescue_proto_mode and GameManager.accident_state == "NONE" \
			and mount.state == "RIDING":
		rescue_proto_reset_t = maxf(rescue_proto_reset_t - delta, 0.0)
		if rescue_proto_reset_t <= 0.0:
			_arm_rescue_proto(rescue_proto_air_mode)
			return

	# BRO METER 第三格：事故恢复完成后播联合惩罚，然后复位、清空、短暂保护。
	if joint_show_t > 0.0:
		joint_show_t = maxf(joint_show_t - delta, 0.0)
		_hold_joint_pose()
		_update_display()
		_update_camera()
		queue_redraw()
		if joint_show_t <= 0.0:
			_end_joint_show()
		return
	if GameManager.bro_joint_pending and GameManager.accident_state == "NONE" \
			and emergency_timer <= 0.0:
		_start_joint_show()
		return

	var control: String = GameManager.current_control
	var rabbit_down: bool = GameManager.accident_state in [
		"RABBIT_SLIP", "RABBIT_WATER", "RABBIT_AIR", "OXYGEN_OUT"
	]
	var turtle_controlled: bool = control == "turtle" and not turtle.accident
	var rabbit_controlled: bool = control == "rabbit" and not rabbit_down \
		and rabbit_stun <= 0.0 and not showtime_active
	# 加速带是位置奖励，不是速度档位：操控乌龟时进带自动提速，不用按键。
	var boosting: bool = turtle_controlled and _in_boost_lane()
	# 垂直轴只属于乌龟：↑ 跃起、↓ 下潜。↑ 同时是兔子的跳跃键，
	# 但同一时刻只有一个角色受控，所以不会互相抢输入。
	var vertical := 0.0
	if turtle_controlled:
		if Tuning.SURFBOARD_PHYSICS:
			# 下潜只在玩家按住 ↓ 时成立；松开就按浮力上浮。
			# 不再有“尾端自动上浮”：接人时机是玩家的操作（BRO DIVE 的要求）。
			if Input.is_action_pressed("down"):
				vertical = 1.0
		else:
			vertical = Input.get_axis("up", "down")
	if emergency_timer > 0.0:
		# 氧气耗尽：强制上浮，玩家暂时只能看着。
		vertical = -1.0
		boosting = false

	# 乌龟跃起：整组上抛，兔子被带动，不需要再按跳。
	# 只受控时触发；SHIFT 只交权，不提供免费动作。
	if turtle_controlled and Tuning.SURFBOARD_PHYSICS \
			and GameManager.accident_state in ["NONE", "RABBIT_AIR"] \
			and not showtime_active \
			and Input.is_action_just_pressed("up") and turtle.start_leap():
		GameManager.feedback.emit(Locale.t("feedback.leap"), "pop")

	# 待命不恶化、也不替玩家清失衡：auto_cruise 只保留给旧模型兼容。
	turtle.tick(delta, turtle_controlled, boosting, vertical,
		true, BOOST_LANE_SPEED if _in_boost_lane() else Tuning.BOOST_SPEED)

	if showtime_active:
		_tick_showtime(delta)
	else:
		_tick_rabbit(delta, rabbit_controlled, boosting)

	if GameManager.accident_state == "NONE" and emergency_timer <= 0.0:
		_check_hazards()

	# Phase G：daze_time 不再单独触发事故。它只是姿态/短硬直，
	# 每一次有效失误都在发生当下记进 BRO METER，第三格才出联合事故。

	_update_oxygen(delta)
	_update_combo()
	_update_lessons()
	_update_boost_lesson()
	_update_display()
	_update_camera()

	if turtle.position.x >= world_end and not test_no_finish:
		_begin_finish()
		return
	queue_redraw()


func _update_zone() -> void:
	var zone := LevelDataScript.zone_at(turtle.position.x)
	if zone["id"] != current_zone["id"]:
		current_zone = zone
		GameManager.note_zone(zone["id"], zone["name"])
		GameManager.center_message.emit(
			Locale.t("center.zone", [zone["id"], Locale.zone_name(zone["id"])]),
			zone["grade_color"])
		GameManager.hint.emit(Locale.zone_lesson(zone["id"]))
		queue_redraw()


## 首次遇到某一类障碍时，底部中央只教一次“该按什么”，之后靠形状/高度/位置读。
## 不再在世界里挂黄色标签，也不在 HUD 顶部重复“障碍名 + 距离 + 动作”。
func _update_lessons() -> void:
	# 救援/事故期间不要再弹“下一组障碍”的首次教学，否则会把救援提示顶掉。
	if GameManager.accident_state != "NONE":
		return
	for g in hazard_groups:
		var kind: String = g["kind"]
		if lesson_seen.has(kind):
			continue
		var d: float = LevelDataScript.group_start(g) - turtle.position.x
		if d < 0.0 or d > Tuning.PROMPT_RANGE:
			continue
		lesson_seen[kind] = true
		match kind:
			"SURFACE_ROCK":
				GameManager.prompt.emit(Locale.t("prompt.jump"))
			"LOW_BEAM", "LOW_BIRD":
				GameManager.prompt.emit(Locale.t("prompt.crouch"))
			"SHARK":
				GameManager.prompt.emit(Locale.t("prompt.leap"))
			"DIVE_GATE":
				GameManager.prompt.emit(Locale.t("prompt.dive"))
			"FLOATING_LOG":
				GameManager.prompt.emit(Locale.t("prompt.combo"))
			"HIGH_WALL":
				GameManager.prompt.emit(Locale.t("prompt.ollie"))


func _update_boost_lesson() -> void:
	# 第一次进加速带时讲一次“按住 RIGHT”和“兔子滑落更快”。
	# 只发提示，不改赛道布局，也不自动替玩家加速。
	if boost_lesson_seen:
		return
	if not _in_boost_lane():
		return
	boost_lesson_seen = true
	GameManager.hint.emit(Locale.t("hint.boost"))


func _begin_finish() -> void:
	if finishing:
		return
	finishing = true
	finish_timer = FINISH_DELAY
	GameManager.finalize_run()
	GameManager.center_message.emit(
		Locale.t("center.finish", [
			GameManager.grade, Locale.grade_title(GameManager.grade)]),
		Color(1.0, 0.85, 0.25))
	queue_redraw()


func _tick_rabbit(delta: float, rabbit_controlled: bool, boosting: bool) -> void:
	# BRO OLLIE：乌龟跃起期间，兔子仍可以主动蹬踏离壳（独立的一次弹跳）。
	# 这是高墙的唯一解法：乌龟的跃起只把壳送进窗口，壳上的兔子会撞墙楣，
	# 必须由玩家切到兔子补这一下，越过墙楣顶再落回壳上。
	if rabbit_controlled and mount.state == "RIDING" and turtle.leap_active \
			and Input.is_action_just_pressed("up"):
		rabbit.launch(turtle.get_mount_point(), turtle.speed,
			Tuning.OLLIE_KICK_VELOCITY)
		mount.mark_airborne()
	# 乌龟跃起期间兔子被整组带动：不抢跳、不趴低，只跟着壳走。
	# 组合漂浮物里兔子先跳、再 SHIFT 给乌龟下潜——跳跃不会被换人取消，
	# 因为 tick_air 不看控制权，只受重力。
	if rabbit_controlled and mount.state == "RIDING" and not turtle.leap_active \
			and Input.is_action_just_pressed("up") and turtle.is_at_surface():
		rabbit.launch(turtle.get_mount_point(), turtle.speed)
		mount.mark_airborne()

	if mount.state == "RIDING":
		if rabbit_stun > 0.0:
			rabbit.tick_stun(delta, turtle.get_mount_point())
		elif turtle.leap_active:
			rabbit.tick_riding(delta, turtle.get_mount_point(), false, false, false)
		else:
			rabbit.tick_riding(delta, turtle.get_mount_point(), rabbit_controlled,
				boosting,
				not (GameManager.accident_state in ["RABBIT_SLIP", "RABBIT_WATER"]),
				rabbit_grace > 0.0)
	elif mount.state == "AIRBORNE":
		rabbit.tick_air(delta, rabbit_controlled)
	elif mount.state == "RESCUING":
		# 失败恢复也让兔子“被冲回来”，不要瞬移到壳上。
		rabbit.position = rabbit.position.move_toward(
			Vector2(turtle.position.x - 60.0, SURFACE_Y + 12.0), 560.0 * delta)

	if mount.state == "AIRBORNE":
		# 跃起期间壳不收人：BRO OLLIE 的兔子正处在墙楣上方（离壳 60～120 px），
		# 半空收人会把兔子直接拽回壳上、拖进墙楣。落回必须等跃起结束、兔子下坠到位。
		GameManager.pickup_window = not turtle.leap_active \
			and mount.can_pickup(rabbit.position, rabbit.velocity.y,
				turtle.get_mount_point(), turtle.is_at_surface(), turtle.is_rising())
		if GameManager.pickup_window:
			rabbit.attach(turtle.get_mount_point())
			mount.mark_riding()
			GameManager.pickup_count += 1
			GameManager.pickup_success.emit()
		elif rabbit.position.y > SURFACE_Y + 40.0 and rabbit.velocity.y > 0.0:
			_trigger_accident("RABBIT_WATER")
	else:
		GameManager.pickup_window = false

	# Phase G：滑移到临界不再自动落水。兔子被撞的当下已经记了一格 BRO METER，
	# 不能再用同一串碰撞在几秒后追罚第二次。


func _tick_recovery(delta: float) -> void:
	if mount.state == "RESCUE_AIR":
		# 方案 2 原型：兔子在空中下落；只有乌龟正在跃起时才有高度接住。
		rabbit.velocity.y = minf(rabbit.velocity.y
			+ Tuning.RESCUE_AIR_GRAVITY * delta, 900.0)
		rabbit.position.y += rabbit.velocity.y * delta
		var air_expired: bool = mount.tick_rescue_air(delta)
		var air_mp: Vector2 = turtle.get_mount_point()
		if mount.can_rescue_air_catch(rabbit.position, air_mp, turtle.leap_active):
			_rescue_catch(air_mp)
		elif air_expired or rabbit.position.y >= Tuning.RESCUE_AIR_WATER_Y \
				or turtle.position.x > rabbit.position.x + 280.0:
			_rescue_miss()

	if mount.state == "RESCUE_ACTIVE":
		# 兔子在水里缓慢下沉；玩家要把乌龟潜到它下面。
		rabbit.position.y = minf(rabbit.position.y + Tuning.RESCUE_RABBIT_SINK * delta,
			760.0)
		var expired: bool = mount.tick_rescue_active(delta)
		var mp: Vector2 = turtle.get_mount_point()
		if mount.can_rescue_catch(rabbit.position, mp):
			_rescue_catch(mp)
		elif expired or turtle.position.x > rabbit.position.x + 280.0:
			_rescue_miss()

	if mount.state == "RESCUING":
		if mount.tick_rescue(delta):
			rabbit.attach(turtle.get_mount_point())
			mount.mark_riding()
			GameManager.accident_state = "NONE"
			GameManager.oxygen = maxf(GameManager.oxygen, Tuning.OXYGEN_RECOVERED)
			rabbit_grace = Tuning.GRACE_TIME
			GameManager.rescue_done.emit()

	if rabbit_stun > 0.0:
		rabbit_stun -= delta
		# 撞一下的减速要看得见：硬直期间把速度压在 140。
		turtle.speed = minf(turtle.speed, 140.0)
		if rabbit_stun <= 0.0:
			rabbit_stun = 0.0
			if GameManager.accident_state == "RABBIT_STUN":
				GameManager.accident_state = "NONE"
			rabbit.state = "RIDING"
			rabbit_grace = 1.0

	if emergency_timer > 0.0:
		emergency_timer -= delta
		# 冲浪板模型的“浮出水面”就是回到巡航水深，不用旧水线 300。
		var rescue_y := surface_ref()
		turtle.position.y = move_toward(turtle.position.y, rescue_y, 240.0 * delta)
		if emergency_timer <= 0.0 or turtle.position.y <= rescue_y + 1.0:
			emergency_timer = 0.0
			turtle.position.y = rescue_y
			turtle.daze_time = 0.0
			turtle.state = "CRUISING"
			turtle.speed = 180.0
			GameManager.oxygen = Tuning.OXYGEN_RECOVERED
			GameManager.accident_state = "NONE"
			rabbit.state = "RIDING"
			rabbit.slide = 0.0
			rabbit.daze_time = 0.0
			rabbit_grace = 1.0
			turtle_grace = 1.0
			GameManager.rescue_done.emit()

	if turtle.accident:
		turtle_repair -= delta
		if turtle_repair <= 0.0:
			turtle.accident = false
			turtle.position.y = surface_ref()
			turtle.speed = 180.0
			turtle.state = "CRUISING"
			turtle.daze_time = 0.0
			# 修好之后别再被残留的 dunk 拽回水下：复位必须包含它。
			turtle.dunk_timer = 0.0
			turtle_grace = Tuning.GRACE_TIME
			GameManager.accident_state = "NONE"
			GameManager.rescue_done.emit()


## 主动救援成功：兔子抓住壳，回到骑乘；这是一次玩家动作，不是计时器放回。
func _rescue_catch(mp: Vector2) -> void:
	rescue_last_result = "caught"
	rabbit.attach(mp)
	mount.mark_riding()
	GameManager.accident_state = "NONE"
	GameManager.oxygen = maxf(GameManager.oxygen, Tuning.OXYGEN_RECOVERED)
	GameManager.prompt.emit("")
	rabbit_grace = Tuning.RESCUE_GRACE_TIME
	GameManager.feedback.emit(Locale.t("feedback.rescue_ok"), "pop")
	GameManager.rescue_done.emit()
	if rescue_proto_mode:
		print("RESCUE PROTO: caught mode=%s" % ("air" if rescue_proto_air_mode else "water"))
		_write_realinput_result("caught")
		rescue_proto_reset_t = 1.6


## 没接住：兔子被水流冲回壳上（有限恢复，不再触发第二次事故）。
func _rescue_miss() -> void:
	rescue_last_result = "missed"
	mount.mark_rescuing(Tuning.RESCUE_RETURN_TIME)
	GameManager.prompt.emit("")
	GameManager.feedback.emit(Locale.t("feedback.rescue_miss"), "hit")
	if rescue_proto_mode:
		print("RESCUE PROTO: missed mode=%s" % ("air" if rescue_proto_air_mode else "water"))
		_write_realinput_result("missed")
		rescue_proto_reset_t = 2.2


## 窗口化真实按键测试没有可读 stdout 时，用这个文件判定成功/失败。
## 只有带 --capture-rescue 的窗口化运行才写，自动探针不碰。
func _write_realinput_result(result: String) -> void:
	if not ("--capture-rescue" in OS.get_cmdline_user_args()):
		return
	var f := FileAccess.open(
		ProjectSettings.globalize_path("res://docs/reports/longrun/phase-f-realinput-last.txt"),
		FileAccess.WRITE)
	if f != null:
		f.store_string("%s %s %s\n" % [result,
			"air" if rescue_proto_air_mode else "water",
			Time.get_datetime_string_from_system()])
		f.close()


func _trigger_accident(reason: String) -> void:
	if hazard_cooldown > 0.0 or GameManager.accident_state != "NONE":
		return
	if showtime_active:
		showtime_active = false
		GameManager.showtime_active = false
		rabbit.showtime_spin = 0.0
		rabbit.showtime_pose = false
	hazard_cooldown = Tuning.TURTLE_COOLDOWN if reason == "TURTLE_REEF" \
		else Tuning.HAZARD_COOLDOWN
	accident_flash = Tuning.ACCIDENT_FLASH
	_accident_t = 0.0
	GameManager.accident_state = reason
	# accident_count / 扣分 / BRO METER 都在 note_accident -> note_mistake 里，
	# 避免事故入口与海浪碰撞各记一套。
	GameManager.note_accident(reason)
	combo = 0
	GameManager.combo = 0
	GameManager.accident.emit(reason)

	match reason:
		"RABBIT_SLIP":
			rabbit.state = "FALLING_WATER"
			rabbit.velocity = Vector2.ZERO
			mount.mark_rescuing(Tuning.RESCUE_TIME)
			GameManager.set_control("turtle")
		"RABBIT_WATER":
			# 不再自动放回：兔子漂在乌龟前方，玩家切乌龟/下潜去接。
			# 控制权不强制交回——如果刚才在兔子身上，SHIFT 本身就是救援的第一步。
			rabbit.state = "FALLING_WATER"
			rabbit.velocity = Vector2.ZERO
			rabbit.position = Vector2(
				turtle.position.x + Tuning.RESCUE_RABBIT_AHEAD,
				Tuning.RESCUE_RABBIT_DEPTH)
			mount.mark_rescue_active(Tuning.RESCUE_ACTIVE_TIME)
			GameManager.prompt.emit(Locale.t(
				"prompt.rescue_shift" if GameManager.current_control == "rabbit"
				else "prompt.rescue_dive"))
		"RABBIT_AIR":
			# 方案 2 原型：兔子被抛到空中；玩家可以 SHIFT 到乌龟，再按 ↑ 跃起接住。
			rabbit.state = "FALLING_WATER"
			rabbit.velocity = Vector2(0.0, 0.0)
			rabbit.position = Vector2(
				turtle.position.x + Tuning.RESCUE_AIR_AHEAD,
				Tuning.RESCUE_AIR_START_Y)
			mount.mark_rescue_air(Tuning.RESCUE_AIR_TIME)
			GameManager.prompt.emit(Locale.t(
				"prompt.rescue_leap_shift" if GameManager.current_control == "rabbit"
				else "prompt.rescue_leap"))
		"RABBIT_STUN":
			# 短硬直是碰撞后果，不是控制锁：不强制换人，玩家自己决定要不要换。
			rabbit.state = "STUNNED"
			rabbit_stun = Tuning.STUN_TIME
			turtle.speed *= 0.6
		"TURTLE_REEF":
			turtle.accident = true
			turtle_repair = Tuning.REPAIR_TIME
			turtle.state = "UNCONSCIOUS"
			GameManager.set_control("rabbit")
		"OXYGEN_OUT":
			rabbit.state = "PASSED_OUT"
			emergency_timer = Tuning.EMERGENCY_TIME
			GameManager.set_control("turtle")


func _rabbit_contact() -> void:
	if mount.state == "AIRBORNE" or rabbit.is_airborne():
		_trigger_accident("RABBIT_WATER")
	else:
		# 撞一次不是立刻摔：加一段失衡，姿态马上变差，继续错才会到临界。
		rabbit.add_imbalance(Tuning.RABBIT_HIT_IMBALANCE)
		_trigger_accident("RABBIT_STUN")


## 浪击：乌龟失衡 + 整组短暂没入水下 + 明显减速。
## Phase G：它是一次“失误”，当场记 1 格 BRO METER；失衡只做短硬直，
## 不再有“攒到 9.5 再补一次翻肚皮”的第二套惩罚。
func _turtle_contact(_key: String) -> void:
	turtle.add_imbalance(Tuning.TURTLE_HIT_IMBALANCE)
	turtle.start_dunk()
	turtle.speed *= 0.6
	accident_flash = Tuning.ACCIDENT_FLASH
	GameManager.feedback.emit(Locale.t("feedback.wave_hit"), "hit")
	GameManager.hint.emit(Locale.t("hint.wave_hit"))
	GameManager.note_mistake("TURTLE_WAVE")


## 旧的“壳沉太深”暗流不再存在：乌龟待命也停在巡航水深。
## 保留这个查询给 HUD/旧测试调用，永远返回 false。
func undertow_active() -> bool:
	return false


func _check_hazards() -> void:
	if test_disable_hazards:
		return
	var t_rect := _inset(turtle.get_body_rect(), 3.0)
	var r_rect := _inset(rabbit.get_body_rect(), 3.0)
	for g in hazard_groups:
		var group: Dictionary = g
		# 每组只判一次：撞过就标脏，不会因为还卡在里面而每帧重复加失衡。
		if hit_groups.has(group["group"]):
			continue
		for r in group["rects"]:
			var rect: Rect2 = r
			match group["kind"]:
				"LOW_BEAM", "LOW_BIRD":
					# A 类：只占兔子站立的那一层。趴在壳上就过，龟壳不受影响。
					if r_rect.intersects(rect) and rabbit.state != "CROUCHING":
						hit_groups[group["group"]] = true
						_rabbit_contact()
						return
				"SURFACE_ROCK":
					# A 类（跳跃）：只压兔子；龟壳顶从岩石下沿让开 10 px。
					if r_rect.intersects(rect):
						# 起跳上升帧允许越过岩檐；下落仍会撞上。
						if rabbit.state == "JUMPING" and rabbit.velocity.y < 0.0:
							continue
						hit_groups[group["group"]] = true
						_rabbit_contact()
						return
				"SHARK":
					# C 类：只判乌龟。跃起把整组带高，兔子跟着壳，不需要额外动作。
					if t_rect.intersects(rect):
						hit_groups[group["group"]] = true
						_turtle_contact(group["group"])
						return
				"DIVE_GATE":
					# D 类：只判乌龟。下潜到位后整个壳（连同壳上的兔子）从下方过。
					if t_rect.intersects(rect):
						hit_groups[group["group"]] = true
						_turtle_contact(group["group"])
						return
				"FLOATING_LOG":
					# B 类（组合）：上沿是兔子路线，下沿是乌龟路线，两条路径分别判。
					if r_rect.intersects(rect):
						hit_groups[group["group"]] = true
						_rabbit_contact()
						return
					if t_rect.intersects(rect):
						hit_groups[group["group"]] = true
						_turtle_contact(group["group"])
						return
				"HIGH_WALL":
					# E 类（BRO OLLIE）：墙楣只压骑乘兔，墙身压巡航壳。
					# 跃起只把壳送进窗口；壳上的兔子会撞墙楣，必须玩家补一次蹬踏。
					if r_rect.intersects(rect):
						hit_groups[group["group"]] = true
						_rabbit_contact()
						return
					if t_rect.intersects(rect):
						hit_groups[group["group"]] = true
						_turtle_contact(group["group"])
						return


func _update_oxygen(delta: float) -> void:
	if emergency_timer > 0.0 or GameManager.accident_state != "NONE":
		return
	if mount.state != "RIDING":
		return
	var air_line := SURFACE_Y + 20.0
	if Tuning.SURFBOARD_PHYSICS:
		air_line = Tuning.NEUTRAL_DEPTH + Tuning.OXYGEN_DEPTH_MARGIN
	if turtle.position.y > air_line:
		GameManager.oxygen = maxf(GameManager.oxygen - delta * Tuning.OXYGEN_DRAIN, 0.0)
		if GameManager.oxygen <= 0.0:
			_trigger_accident("OXYGEN_OUT")
	else:
		GameManager.oxygen = minf(
			GameManager.oxygen + delta * Tuning.OXYGEN_RECOVER, Tuning.OXYGEN_MAX)
	var phase := oxygen_phase()
	if phase != _oxygen_phase:
		if phase == "LOW":
			GameManager.hint.emit(Locale.t("hint.air_low"))
		elif phase == "CRITICAL":
			GameManager.hint.emit(Locale.t("hint.air_critical"))
		_oxygen_phase = phase
	GameManager.oxygen_phase = phase


func oxygen_phase() -> String:
	if GameManager.oxygen <= 0.01:
		return "EMPTY"
	if GameManager.oxygen <= Tuning.OXYGEN_CRITICAL:
		return "CRITICAL"
	if GameManager.oxygen <= Tuning.OXYGEN_LOW:
		return "LOW"
	return "SAFE"


func _update_combo() -> void:
	for g in hazard_groups:
		var group: Dictionary = g
		var key: String = group["group"]
		if passed_groups.has(key):
			continue
		var start_x := _group_start(group)
		var end_x := _group_end(group)
		# 必须先真正靠近/穿过障碍才具备“通过”资格。
		# 否则瞬移（测试、调试或未来任何跳转）会把身后的整段障碍误算成连击。
		if turtle.position.x >= start_x - 120.0 and turtle.position.x <= end_x + 120.0:
			entered_groups[key] = true
		# 精准动作只在横穿带里采样：起跳/下潜都要在障碍真正经过时仍然成立。
		if not passed_groups.has(key) \
				and turtle.position.x > start_x - ACT_BAND \
				and turtle.position.x < end_x + ACT_BAND:
			_sample_action(key)
		if turtle.position.x > end_x + 80.0 and entered_groups.get(key, false):
			passed_groups[key] = true
			if GameManager.accident_state != "NONE" or hit_groups.get(key, false):
				# 事故期间越过的障碍不补算连击，避免恢复后“隔空”加数。
				combo = 0
			else:
				combo = mini(combo + 1, Tuning.SHOWTIME_COMBO)
				combo_max = maxi(combo_max, combo)
				var kind: String = String(group["kind"])
				var act: Dictionary = group_actions.get(key, {})
				var precise := _precise_action(kind, act)
				if combo >= Tuning.SHOWTIME_COMBO:
					GameManager.feedback.emit(Locale.t("feedback.bro_combo"), "bro")
				if precise:
					# 连招整段完成才给 250/300；精准单动作 150；其余干净通过 100。
					GameManager.note_precise_pass(kind)
					match kind:
						"FLOATING_LOG":
							GameManager.feedback.emit(Locale.t("feedback.bro_dive"), "bro")
						"HIGH_WALL":
							GameManager.feedback.emit(Locale.t("feedback.bro_ollie"), "bro")
						_:
							GameManager.feedback.emit(Locale.t("feedback.clean"), "clean")
				else:
					GameManager.note_clean_pass()
					GameManager.feedback.emit(Locale.t("feedback.clean"), "clean")
	GameManager.combo = combo
	GameManager.combo_max = combo_max
	if combo >= Tuning.SHOWTIME_COMBO and not showtime_active \
			and GameManager.accident_state == "NONE" and mount.state == "RIDING" \
			and _showtime_clear_ahead():
		start_showtime()


## 横穿带里每帧采样一次：这个障碍到底是靠哪个动作过的。
## 只看障碍真正经过的那一小段，提前很远的乱跳不算数。
func _sample_action(key: String) -> void:
	var a: Dictionary = group_actions.get(key, {})
	var rabbit_air: bool = rabbit.state == "JUMPING" or rabbit.state == "FALLING"
	if rabbit_air:
		a["jumped"] = true
	if rabbit.state == "CROUCHING":
		a["crouched"] = true
	if turtle.position.y > surface_ref() + 80.0:
		a["dived"] = true
	if turtle.leap_active:
		a["leaped"] = true
		# 壳在跃起、兔子却已经离壳：这才是 BRO OLLIE 的“二段蹬踏”。
		if rabbit_air or mount.state == "AIRBORNE":
			a["kicked"] = true
	group_actions[key] = a


func _precise_action(kind: String, a: Dictionary) -> bool:
	match kind:
		"SURFACE_ROCK":
			return bool(a.get("jumped", false))
		"LOW_BEAM", "LOW_BIRD":
			return bool(a.get("crouched", false))
		"SHARK":
			return bool(a.get("leaped", false))
		"DIVE_GATE":
			return bool(a.get("dived", false))
		"FLOATING_LOG":
			# 兔子跳 + 乌龟潜，两段都在障碍横穿带里成立才算 BRO DIVE。
			return bool(a.get("jumped", false)) and bool(a.get("dived", false))
		"HIGH_WALL":
			# 壳跃起 + 兔子蹬踏离壳，缺一段就只是撞墙。
			return bool(a.get("leaped", false)) and bool(a.get("kicked", false))
	return false


func _start_joint_show() -> void:
	joint_show_t = JOINT_SHOW_TIME
	_joint_turtle_y = turtle.position.y
	GameManager.accident_state = "BRO_BREAK"
	hazard_cooldown = JOINT_SHOW_TIME + 1.2
	accident_flash = 0.8
	turtle.speed = 0.0
	GameManager.center_message.emit(Locale.t("center.bro_full"),
		Color(1.0, 0.35, 0.3))
	# 第三格的反馈就是联合惩罚本身；底部的旧碰撞提示/海浪建议会变成干扰
	# （玩家这时读到的会是“换回乌龟稳住”，和正在播的联合惩罚互相矛盾）。
	GameManager.prompt.emit("")
	GameManager.hint.emit("")


func _hold_joint_pose() -> void:
	# 原地抖动 + 闪白：够短，不抢玩家的判断时间，但看得出“这是第三格”。
	var t := JOINT_SHOW_TIME - joint_show_t
	turtle.position.y = _joint_turtle_y + absf(sin(t * 30.0)) * 4.0
	turtle.speed = 0.0
	rabbit.position = turtle.get_mount_point() + Vector2(0.0,
		absf(sin(t * 30.0 + 0.6)) * 6.0)


func _end_joint_show() -> void:
	joint_show_t = 0.0
	turtle.reset(Vector2(turtle.position.x, surface_ref()))
	turtle.speed = current_zone["base_speed"]
	rabbit.reset()
	rabbit.attach(turtle.get_mount_point())
	mount.reset()
	mount.mark_riding()
	GameManager.accident_state = "NONE"
	GameManager.clear_bro_meter()
	rabbit_grace = 1.5
	turtle_grace = 1.5
	# 联合惩罚结束不是“获救”：发 rescue_done 会让横幅错误显示“获救”。
	GameManager.center_message.emit(Locale.t("center.bro_recover"),
		Color(0.5, 1.0, 0.6))


## 表演 1.8 s 把控制权锁在乌龟，结束后还有 1 s 的恢复宽限（龟壳自动巡航、
## 下沉计时清零）。这段窗口里兔子的跳/趴做不了，下沉门也沉不下去——
## 连击刚好卡在障碍前触发表演，就变成“庆祝完直接撞”。
## 因此表演只在前面 900 px 没有兔子层障碍时开始；连击封顶在 3，
## 空档一到就会补上，不会丢奖励。
func _showtime_clear_ahead() -> bool:
	for g in hazard_groups:
		var group: Dictionary = g
		if not (group["kind"] in ["SURFACE_ROCK", "LOW_BEAM", "LOW_BIRD",
				"SHARK", "DIVE_GATE", "FLOATING_LOG"]):
			continue
		if turtle.position.x > _group_end(group) + 80.0:
			continue
		if _group_start(group) - turtle.position.x < SHOWTIME_CLEAR:
			return false
	return true


func start_showtime() -> void:
	if showtime_active or GameManager.accident_state != "NONE":
		return
	showtime_active = true
	GameManager.showtime_active = true
	showtime_t = 0.0
	combo = 0
	GameManager.combo = 0
	showtime_prev_control = GameManager.current_control
	# 表演由兔子自动完成，但不抢玩家的控制权：奖励不应该打断正在做的判断。
	GameManager.center_message.emit(Locale.t("center.showtime"),
		Color(1.0, 0.85, 0.25))


func _tick_showtime(delta: float) -> void:
	showtime_t += delta
	var p := clampf(showtime_t / Tuning.SHOWTIME_TIME, 0.0, 1.0)
	var base: Vector2 = turtle.get_mount_point()
	var offset := 0.0
	var spin := 0.0
	if p < 0.31:
		var q := p / 0.31
		offset = -sin(q * PI) * 90.0
		spin = q * TAU * 2.0
	elif p < 0.64:
		offset = -absf(sin((p - 0.31) * 30.0)) * 6.0
		spin = TAU * 2.0
	else:
		offset = -4.0
		spin = TAU * 2.0
	rabbit.state = "SHOWTIME"
	rabbit.showtime_spin = spin
	rabbit.showtime_pose = p >= 0.64
	rabbit.position = base + Vector2(0.0, offset)
	if showtime_t >= Tuning.SHOWTIME_TIME:
		_end_showtime(true)


func _end_showtime(completed: bool) -> void:
	if not showtime_active:
		return
	showtime_active = false
	GameManager.showtime_active = false
	rabbit.showtime_spin = 0.0
	rabbit.showtime_pose = false
	rabbit.attach(turtle.get_mount_point())
	mount.mark_riding()
	if completed:
		# Showtime 不再瞬间回满氧气，只给小幅回复；氧气不能被表演白送。
		GameManager.oxygen = minf(GameManager.oxygen + Tuning.SHOWTIME_OXYGEN,
			Tuning.OXYGEN_MAX)
		GameManager.oxygen_phase = oxygen_phase()
		GameManager.showtime_count += 1
		GameManager.note_showtime()
		turtle_grace = 1.0
		rabbit_grace = 1.0
		GameManager.center_message.emit(Locale.t("center.brotherhood"),
			Color(1.0, 0.85, 0.25))
	else:
		# 中断：跳过提示期，兔子直接从滑落读秒；控制权不抢。
		rabbit.force_slip()
		rabbit_grace = 0.0
		GameManager.center_message.emit(Locale.t("center.shows_over"),
			Color(0.8, 0.85, 0.9))


func showtime_left() -> float:
	return maxf(Tuning.SHOWTIME_TIME - showtime_t, 0.0)


func _group_start(group: Dictionary) -> float:
	var start_x := 1.0e9
	for r in group["rects"]:
		var rect: Rect2 = r
		start_x = minf(start_x, rect.position.x)
	return start_x


func _group_end(group: Dictionary) -> float:
	var end_x := 0.0
	for r in group["rects"]:
		var rect: Rect2 = r
		end_x = maxf(end_x, rect.end.x)
	return end_x


func next_hazard_info() -> Dictionary:
	var best := {}
	var best_d := 1.0e9
	for g in hazard_groups:
		var group: Dictionary = g
		var rect: Rect2 = group["rects"][0]
		var d: float = rect.position.x - turtle.position.x
		if d < -60.0:
			continue
		if d < best_d:
			best_d = d
			best = {
				"group": group["group"],
				"kind": group["kind"],
				"distance": maxf(d, 0.0),
				"end": _group_end(group),
				"hint": group["hint"],
				"action": group["action"],
			}
	return best


func surface_y() -> float:
	# HUD 的“水下”提示跟着模型基准走：旧模型 300，冲浪板模型巡航水深。
	return surface_ref()


func zone_name() -> String:
	return current_zone["name"]


func zone_id() -> int:
	return current_zone["id"]


func progress() -> float:
	return clampf(turtle.position.x / world_end, 0.0, 1.0)


func total_groups() -> int:
	return hazard_groups.size()


func passed_count() -> int:
	return passed_groups.size()


## HUD 只用这两个数：当前的晃动强度。
## Phase G 后 daze_time 封顶在 DAZE_CAP，归一化必须也用它——
## 旧分母 9.5 会让条永远停在 38%，等于把“还有一套隐藏风险”画在屏幕上。
## 待命时 daze_time 冻结，所以待命不会让这两个数自己变大。
func rabbit_imbalance_pct() -> int:
	if rabbit == null:
		return 0
	return clampi(int(round(rabbit.daze_time / Tuning.DAZE_CAP * 100.0)), 0, 100)


func turtle_imbalance_pct() -> int:
	if turtle == null:
		return 0
	return clampi(int(round(turtle.daze_time / Tuning.DAZE_CAP * 100.0)), 0, 100)


func _in_boost_lane() -> bool:
	if turtle.position.y > surface_ref() + 60.0:
		return false
	for lane in boost_lanes:
		var rect: Rect2 = lane
		if turtle.position.x >= rect.position.x and turtle.position.x <= rect.end.x:
			return true
	return false


func _inset(rect: Rect2, n: float) -> Rect2:
	return Rect2(rect.position + Vector2(n, n),
		rect.size - Vector2(n * 2.0, n * 2.0))


func _update_display() -> void:
	GameManager.turtle_state = turtle.state
	GameManager.rabbit_state = rabbit.state
	if turtle.state in ["RELAXED", "SINKING", "DEEP", "CRITICAL"]:
		GameManager.turtle_phase = turtle.phase_label()
	else:
		GameManager.turtle_phase = turtle.state
	if rabbit.state in ["RELAXED", "SLIDING", "EDGE", "CRITICAL"]:
		GameManager.rabbit_phase = rabbit.phase_label()
	else:
		GameManager.rabbit_phase = rabbit.state
	GameManager.turtle_speed = turtle.speed
	GameManager.slide_progress = rabbit.slide
	GameManager.mount_state = mount.state
	GameManager.combo = combo
	GameManager.combo_max = combo_max
	GameManager.showtime_active = showtime_active
	GameManager.oxygen_phase = oxygen_phase()


## 镜头固定前瞻 300 px，垂直中心压到 300：角色和前方障碍落在画面中段，
## 下面不再是一整屏空水。全程只有 x 跟随，换人不产生镜头跳动。
func _update_camera() -> void:
	if camera != null:
		camera.position = Vector2(turtle.position.x + 300.0, 300.0)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("shift") and showtime_active:
		_end_showtime(false)
		get_viewport().set_input_as_handled()
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_F3:
			debug_mode = not debug_mode
			show_hitboxes = debug_mode
			if _debug_overlay != null:
				_debug_overlay.visible = debug_mode
			queue_redraw()
		elif event.physical_keycode == KEY_F1 and _debug_overlay != null:
			_debug_overlay.visible = not _debug_overlay.visible
		elif event.physical_keycode == KEY_H:
			show_hitboxes = not show_hitboxes
			queue_redraw()


func _draw() -> void:
	var world_width := world_end + 900.0
	# 三个区域各画一段背景；区域边界和名字直接画在世界里。
	for zone in LevelDataScript.ZONES:
		var x0: float = zone["start"] - 400.0
		var w: float = zone["end"] - zone["start"] + 400.0
		draw_rect(Rect2(x0, -200, w, 500), zone["sky"])
		draw_rect(Rect2(x0, SURFACE_Y, w, 700), zone["water"])
		draw_rect(Rect2(x0, 460, w, 440), zone["deep"])
		draw_rect(Rect2(x0, 820, w, 120), zone["seabed"])
		draw_line(Vector2(x0, SURFACE_Y), Vector2(x0 + w, SURFACE_Y),
			Color(0.7, 0.95, 1.0), 4.0)
		if zone["id"] > 1:
			draw_line(Vector2(zone["start"], -200), Vector2(zone["start"], 940),
				Color(1, 1, 1, 0.25), 3.0)
		draw_string(ThemeDB.fallback_font, Vector2(zone["start"] + 40, 80),
			Locale.t("world.zone_header", [zone["id"], Locale.zone_name(zone["id"])]),
			HORIZONTAL_ALIGNMENT_LEFT, -1, 22, zone["grade_color"])

	# 危险深度线只在 F3 调试层出现；正常界面没有红线。
	if debug_mode:
		draw_line(Vector2(-400, 740), Vector2(world_width, 740),
			Color(1.0, 0.3, 0.25, 0.5), 2.0)
		draw_string(ThemeDB.fallback_font, Vector2(turtle.position.x - 200, 726),
			Locale.t("world.danger_depth"), HORIZONTAL_ALIGNMENT_LEFT, -1, 14,
			Color(1.0, 0.5, 0.45, 0.7))

	for lane in boost_lanes:
		_draw_boost_lane(lane)
	draw_rect(Rect2(world_end, 120, 16, 700), Color(1.0, 0.85, 0.2))
	draw_string(ThemeDB.fallback_font, Vector2(world_end - 50, 100),
		Locale.t("world.finish"),
		HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color(1.0, 0.85, 0.2))

	var cam_x: float = camera.position.x if camera != null else turtle.position.x
	for g in hazard_groups:
		var group: Dictionary = g
		for r in group["rects"]:
			_draw_hazard(group["kind"], r)
		if debug_mode and absf(LevelDataScript.group_start(group) - cam_x) <= 1700.0:
			_draw_debug_group(group)

	_draw_action_fx()
	_draw_turtle()
	_draw_rabbit()
	_draw_control_ring()
	if show_hitboxes or debug_mode:
		_draw_hitboxes()

	if accident_flash > 0.0:
		var a: float = 0.55 * (accident_flash / Tuning.ACCIDENT_FLASH)
		draw_rect(Rect2(cam_x - 1400.0, -400.0, 2800.0, 1600.0), Color(1, 1, 1, a))


## 主动垂直动作的灰盒演出：跃起是壳下破水 + 上抛水花；下潜是壳边气泡下压。
## 全部用原生绘制，不引入素材；动作必须“看得出来是主动做的”，不像事故。
func _draw_action_fx() -> void:
	if turtle.leap_active:
		var surf := Tuning.NEUTRAL_DEPTH
		var rise: float = surf - turtle.position.y
		var base := Vector2(turtle.position.x, surf + 10.0)
		# 破水圈：起跳时大、空中收小，读作“从水里弹出来”。
		var spread := 96.0 - 34.0 * clampf(rise / Tuning.LEAP_HEIGHT, 0.0, 1.0)
		for i in 3:
			var rr := spread - i * 16.0
			if rr <= 4.0:
				continue
			draw_arc(base, rr, PI * 0.05, PI * 0.95, 28,
				Color(0.8, 0.97, 1.0, 0.5 - i * 0.12), 5.0)
		for i in 5:
			var ang := PI * (0.2 + 0.6 * float(i) / 4.0)
			draw_circle(base + Vector2(cos(ang), -sin(ang)) * (spread + 10.0),
				5.0, Color(0.9, 1.0, 1.0, 0.5))
		# 向上冲的速度线，明确“整组被带高”。
		for i in 3:
			var y: float = turtle.position.y + 26.0 + i * 18.0
			draw_line(Vector2(turtle.position.x - 40.0, y),
				Vector2(turtle.position.x - 40.0, y + 26.0),
				Color(0.75, 1.0, 1.0, 0.45), 4.0)
	if turtle.diving:
		# 下潜：壳下两串气泡往上冒，方向和水流相反，读作“往下按”。
		for i in 6:
			var t := fmod(_accident_t * 0.9 + i * 0.17, 1.0)
			draw_circle(turtle.position + Vector2(-26.0 + i * 11.0, -30.0 - t * 60.0),
				4.0 - i * 0.35, Color(0.8, 0.95, 1.0, 0.45 * (1.0 - t)))
	if turtle.dunk_timer > 0.0:
		# 被浪打湿：一串气泡从壳边往上冒。
		for i in 5:
			var t := fmod(_accident_t * 0.8 + i * 0.2, 1.0)
			draw_circle(turtle.position + Vector2(-30.0 + i * 15.0, -40.0 - t * 70.0),
				4.0 - i * 0.4, Color(0.8, 0.95, 1.0, 0.5 * (1.0 - t)))


func _draw_boost_lane(rect: Rect2) -> void:
	draw_rect(rect, Color(0.2, 1.0, 0.9, 0.12))
	draw_rect(rect, Color(0.2, 1.0, 0.9, 0.45), false, 2.0)
	for x in range(int(rect.position.x) + 40, int(rect.end.x) - 40, 90):
		var y := rect.position.y + 35.0
		draw_colored_polygon(PackedVector2Array([
			Vector2(x, y - 12), Vector2(x + 26, y), Vector2(x, y + 12),
		]), Color(0.4, 1.0, 0.9, 0.8))
	draw_string(ThemeDB.fallback_font,
		Vector2(rect.position.x + 20, rect.position.y - 10),
		Locale.t("world.boost"), HORIZONTAL_ALIGNMENT_LEFT, -1, 16,
		Color(0.5, 1.0, 0.9, 0.9))


## F3 调试层：ID、类别、该谁动、预期动作、判定框、上下安全通道、触发距离。
## 正常游玩完全不出现；关掉 F3 后世界里的开发标注全部消失。
func _draw_debug_group(group: Dictionary) -> void:
	var start := _group_start(group)
	var first: Rect2 = group["rects"][0]
	var dist := int(round(start - turtle.position.x))
	for r in group["rects"]:
		var rect: Rect2 = r
		draw_rect(rect, Color(1.0, 0.85, 0.2, 0.85), false, 2.0)
	# 组合障碍：把“上安全区 / 下水道”直接画出来，判定框和可走空间一眼对上。
	if group["kind"] == "FLOATING_LOG":
		_draw_safe_channels(group)
	var speed: float = maxf(turtle.speed, 1.0)
	var role := LevelDataScript.role_for_kind(group["kind"])
	var eta := maxf(float(dist), 0.0) / speed
	var label := "#%s  %s  %s  ROLE:%s  ->  %s   d=%d px  t=%.1fs" % [
		group["group"], group["kind"], _category_of(group["kind"]), role,
		Locale.hazard(group["action"]), dist, eta]
	draw_rect(Rect2(first.position.x, first.position.y - 34, 760, 24),
		Color(0.02, 0.05, 0.08, 0.82))
	draw_string(ThemeDB.fallback_font,
		Vector2(first.position.x + 6, first.position.y - 16),
		label, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1.0, 0.9, 0.5))
	var tx := start - Tuning.PROMPT_RANGE
	draw_line(Vector2(tx, 110), Vector2(tx, 520), Color(1.0, 0.8, 0.3, 0.35), 2.0)
	draw_string(ThemeDB.fallback_font, Vector2(tx + 4, 128),
		"TRIGGER %d" % int(Tuning.PROMPT_RANGE),
		HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(1.0, 0.8, 0.3, 0.7))


## 四类障碍的归类。A 类里再分“趴低”和“跳跃”，因为输入不同。
func _category_of(kind: String) -> String:
	match kind:
		"LOW_BIRD", "LOW_BEAM":
			return "A/RABBIT-CROUCH"
		"SURFACE_ROCK":
			return "A/RABBIT-JUMP"
		"FLOATING_LOG":
			return "B/COMBINED"
		"SHARK":
			return "C/TURTLE-LEAP"
		"DIVE_GATE":
			return "D/TURTLE-DIVE"
	return "?"


## 组合漂浮物的可走空间：上安全区（兔子跳）与下水道（乌龟潜）。
func _draw_safe_channels(group: Dictionary) -> void:
	var rect: Rect2 = group["rects"][0]
	var upper := Rect2(rect.position.x, rect.position.y - 260.0,
		rect.size.x, 260.0)
	draw_rect(upper, Color(0.3, 1.0, 0.5, 0.12))
	draw_rect(upper, Color(0.3, 1.0, 0.5, 0.45), false, 2.0)
	draw_string(ThemeDB.fallback_font,
		Vector2(rect.position.x + 4, rect.position.y - 246.0),
		"SAFE ABOVE", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.4, 1.0, 0.6, 0.9))
	var lower := Rect2(rect.position.x, rect.end.y, rect.size.x,
		760.0 - rect.end.y)
	draw_rect(lower, Color(0.3, 0.8, 1.0, 0.12))
	draw_rect(lower, Color(0.3, 0.8, 1.0, 0.45), false, 2.0)
	draw_string(ThemeDB.fallback_font,
		Vector2(rect.position.x + 4, rect.end.y + 18.0),
		"SAFE BELOW", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.5, 0.9, 1.0, 0.9))


func _draw_hazard(kind: String, rect: Rect2) -> void:
	match kind:
		"SURFACE_ROCK":
			draw_rect(rect, Color(0.31, 0.3, 0.29))
			draw_circle(rect.position + Vector2(rect.size.x * 0.3, rect.size.y * 0.5),
				28.0, Color(0.38, 0.36, 0.34))
			draw_circle(rect.position + Vector2(rect.size.x * 0.72, rect.size.y * 0.45),
				24.0, Color(0.35, 0.33, 0.31))
			draw_line(Vector2(rect.position.x, rect.end.y),
				Vector2(rect.end.x, rect.end.y), Color(0.13, 0.12, 0.11), 6.0)
			for i in 4:
				var fx := rect.position.x + 18.0 + i * 34.0
				draw_circle(Vector2(fx, rect.end.y + 4.0), 5.0,
					Color(0.7, 0.95, 1.0, 0.7))
		"LOW_BEAM":
			# 码头低梁：两根立柱扎到海底，横梁从上面压下来。
			# 不是“凭空悬在海面上的杆”——支撑关系必须看得见。
			var post_l := rect.position.x + 10.0
			var post_r := rect.end.x - 10.0
			draw_rect(Rect2(post_l - 7, rect.end.y, 14, 820.0 - rect.end.y),
				Color(0.34, 0.28, 0.2))
			draw_rect(Rect2(post_r - 7, rect.end.y, 14, 820.0 - rect.end.y),
				Color(0.34, 0.28, 0.2))
			draw_rect(rect, Color(0.42, 0.33, 0.22))
			draw_rect(Rect2(rect.position.x, rect.end.y - 12, rect.size.x, 12),
				Color(0.24, 0.18, 0.12))
			# 木头纹理，读作“码头木板”而不是海草。
			for i in 5:
				var by := rect.position.y + 18.0 + i * 16.0
				draw_line(Vector2(rect.position.x + 6, by), Vector2(rect.end.x - 6, by),
					Color(0.33, 0.25, 0.16, 0.7), 2.0)
		"LOW_BIRD":
			# 贴海面低飞的海鸟：身体压在横梁高度，翅膀上下扇。
			# 飞行方向用尾迹和喙标出来，不是静止的方块。
			var cx := rect.position.x + rect.size.x * 0.5
			var cy := rect.position.y + rect.size.y * 0.55
			var flap := sin(Time.get_ticks_msec() * 0.006) * 12.0
			draw_colored_polygon(PackedVector2Array([
				Vector2(cx + 34, cy - 6), Vector2(cx + 4, cy - 14),
				Vector2(cx - 34, cy - 2), Vector2(cx - 30, cy + 10),
				Vector2(cx + 6, cy + 8), Vector2(cx + 34, cy + 4),
			]), Color(0.92, 0.9, 0.84))
			draw_colored_polygon(PackedVector2Array([
				Vector2(cx - 2, cy - 10), Vector2(cx - 26, cy - 34 - flap),
				Vector2(cx + 14, cy - 12),
			]), Color(0.82, 0.8, 0.76))
			draw_colored_polygon(PackedVector2Array([
				Vector2(cx - 2, cy + 6), Vector2(cx - 26, cy + 26 + flap),
				Vector2(cx + 14, cy + 8),
			]), Color(0.78, 0.76, 0.72))
			draw_circle(Vector2(cx + 30, cy - 4), 11.0, Color(0.95, 0.93, 0.86))
			draw_circle(Vector2(cx + 33, cy - 7), 2.5, Color(0.12, 0.12, 0.16))
			draw_colored_polygon(PackedVector2Array([
				Vector2(cx + 40, cy - 2), Vector2(cx + 52, cy + 2),
				Vector2(cx + 40, cy + 5),
			]), Color(1.0, 0.72, 0.28))
			# 尾迹：三根向右（前进方向）的速度线。
			for i in 3:
				var ty := cy - 8.0 + i * 8.0
				draw_line(Vector2(cx - 58.0 - i * 6.0, ty), Vector2(cx - 40.0, ty),
					Color(1.0, 1.0, 1.0, 0.35), 3.0)
		"SHARK":
			# 鲨鱼整条从深水冲上来：判定框就是从头到尾的整条身体，
			# 画法必须占满 rect 的纵向——“下潜也躲不开”才看得懂。
			var sx := rect.position.x + rect.size.x * 0.5
			var top := rect.position.y
			var bot := rect.end.y
			var body_col := Color(0.42, 0.5, 0.58)
			var fin_col := Color(0.36, 0.44, 0.52)
			# 尾鳍（深端）
			draw_colored_polygon(PackedVector2Array([
				Vector2(sx - 12, bot - 40), Vector2(sx - 30, bot - 2),
				Vector2(sx, bot - 20), Vector2(sx + 30, bot - 2),
				Vector2(sx + 12, bot - 40),
			]), fin_col)
			# 身体：头宽、腰收、尾窄。
			# Phase H：头的上沿从 top+34 提到 top+4，贴住判定框上沿。
			# 旧画法让眼睛/嘴浮在框外的 34 px 空白带里，玩家会以为“身体还差一截”，
			# 读不准安全余量；现在框的上沿就是鱼头顶，画的和判的是同一条线。
			draw_colored_polygon(PackedVector2Array([
				Vector2(sx - 30, top + 4), Vector2(sx + 32, top + 4),
				Vector2(sx + 22, top + 96), Vector2(sx + 10, bot - 46),
				Vector2(sx - 10, bot - 46), Vector2(sx - 22, top + 96),
			]), body_col)
			# 背鳍 + 胸鳍
			draw_colored_polygon(PackedVector2Array([
				Vector2(sx - 22, top + 96), Vector2(sx - 52, top + 142),
				Vector2(sx - 18, top + 148),
			]), fin_col)
			draw_colored_polygon(PackedVector2Array([
				Vector2(sx + 20, top + 120), Vector2(sx + 46, top + 150),
				Vector2(sx + 16, top + 154),
			]), fin_col)
			# 嘴和牙：读作“张嘴冲上来”
			draw_rect(Rect2(sx - 26, top + 16, 52, 10), Color(0.9, 0.9, 0.88))
			for i in 6:
				var tx := sx - 24.0 + i * 9.0
				draw_colored_polygon(PackedVector2Array([
					Vector2(tx, top + 26), Vector2(tx + 4, top + 33),
					Vector2(tx + 8, top + 26),
				]), Color(0.95, 0.95, 0.92))
			draw_circle(Vector2(sx - 16, top + 6), 4.0, Color(0.08, 0.08, 0.1))
			draw_circle(Vector2(sx + 18, top + 6), 4.0, Color(0.08, 0.08, 0.1))
			# 上冲气泡
			for i in 4:
				var bx := sx + 26.0 + i * 6.0
				draw_circle(Vector2(bx, top - 16.0 - i * 10.0), 3.0,
					Color(0.85, 0.95, 1.0, 0.5))
		"DIVE_GATE":
			# 水下拱岩：从水面上方横压下来，底沿要画清楚，下面留出安全通道。
			draw_rect(rect, Color(0.3, 0.29, 0.3, 0.95))
			draw_circle(rect.position + Vector2(rect.size.x * 0.25, 20.0), 34.0,
				Color(0.36, 0.34, 0.35))
			draw_circle(rect.position + Vector2(rect.size.x * 0.7, 34.0), 30.0,
				Color(0.33, 0.32, 0.33))
			draw_line(Vector2(rect.position.x, rect.end.y),
				Vector2(rect.end.x, rect.end.y), Color(0.14, 0.13, 0.16), 8.0)
			# 底沿的海草：暗示“这里要往下钻”。
			for i in 6:
				var gx := rect.position.x + 10.0 + i * (rect.size.x - 20.0) / 5.0
				draw_line(Vector2(gx, rect.end.y), Vector2(gx + sin(i * 2.1) * 10.0,
					rect.end.y + 34.0), Color(0.18, 0.4, 0.26), 5.0)
			# 下方通道：两列向上气泡，方向就是“往下走”。
			for i in 5:
				var t := fmod(Time.get_ticks_msec() * 0.0006 + i * 0.2, 1.0)
				draw_circle(Vector2(rect.position.x + 30.0 + i * 30.0,
					rect.end.y + 96.0 - t * 70.0), 3.5,
					Color(0.8, 0.95, 1.0, 0.4 * (1.0 - t)))
		"FLOATING_LOG":
			# 巨型浮木：水上一段木头，水下那段用更深的颜色 + 亮描边单独标出来。
			# 组合障碍必须能看出“上面挡兔子、下面挡乌龟”。
			var lx := rect.position.x
			var lw := rect.size.x
			var log_above := Rect2(lx, rect.position.y,
				lw, maxf(SURFACE_Y - rect.position.y, 0.0))
			var log_under := Rect2(lx, maxf(SURFACE_Y, rect.position.y),
				lw, rect.end.y - maxf(SURFACE_Y, rect.position.y))
			draw_rect(log_above, Color(0.5, 0.36, 0.2))
			draw_rect(Rect2(lx, rect.position.y, lw, 10), Color(0.34, 0.24, 0.13))
			for i in 4:
				draw_line(Vector2(lx + 8.0, rect.position.y + 22.0 + i * 18.0),
					Vector2(lx + lw - 8.0, rect.position.y + 22.0 + i * 18.0),
					Color(0.36, 0.25, 0.14, 0.8), 2.0)
			draw_rect(log_under, Color(0.2, 0.26, 0.26, 0.92))
			draw_rect(log_under, Color(0.55, 0.9, 0.95, 0.85), false, 3.0)
			draw_line(Vector2(lx, rect.end.y), Vector2(lx + lw, rect.end.y),
				Color(0.65, 0.95, 1.0, 0.9), 4.0)
			# 水下段的附着物：一眼能看出它不是浅色背景。
			for i in 5:
				var wx := lx + 12.0 + i * (lw - 24.0) / 4.0
				draw_circle(Vector2(wx, rect.end.y - 12.0), 4.0,
					Color(0.35, 0.55, 0.5, 0.9))
			for i in 3:
				var t := fmod(Time.get_ticks_msec() * 0.0007 + i * 0.3, 1.0)
				draw_circle(Vector2(lx + 26.0 + i * 38.0, rect.end.y + 40.0 - t * 34.0),
					3.0, Color(0.8, 0.95, 1.0, 0.4 * (1.0 - t)))
		"HIGH_WALL":
			# 高墙：墙楣与墙身是两段石头，中间窗口只放得下跃起到顶的壳。
			# 判定框就是这两块石头的形状，画的和判的是同一份 rect。
			draw_rect(rect, Color(0.44, 0.4, 0.36))
			draw_rect(rect, Color(0.18, 0.16, 0.14), false, 3.0)
			var rows := 2 if rect.size.y < 40.0 else 6
			for i in rows:
				var by := rect.position.y + rect.size.y * float(i + 1) / float(rows + 1)
				draw_line(Vector2(rect.position.x + 3.0, by),
					Vector2(rect.end.x - 3.0, by),
					Color(0.3, 0.27, 0.24, 0.85), 2.0)



func _turtle_phase_text() -> String:
	if turtle.accident:
		return Locale.state_name("UNCONSCIOUS")
	if turtle.dunk_timer > 0.0:
		return Locale.state_name("DUNKED")
	match turtle.phase_name():
		"RELAXED":
			return Locale.state_name("UNSTEADY")
		"SINKING":
			return Locale.state_name("WOBBLING")
		"DEEP":
			return Locale.state_name("FLIP_RISK")
		_:
			return Locale.state_name("CRITICAL")


## 失衡姿态是主要预警，不是只靠头顶进度条：
## 兔子按阶段后仰、原地左右晃（早期只晃、不平移）；乌龟按阶段侧倾、慢慢摇，
## 越到临界倾得越多。两个函数同时被 _draw 和自检读，保证“说的”和“画的”一致。
func rabbit_lean() -> float:
	if mount.state != "RIDING" or showtime_active:
		return 0.0
	if rabbit.state in ["JUMPING", "FALLING", "CROUCHING", "FALLING_WATER",
			"STUNNED", "PASSED_OUT", "SHOWTIME"]:
		return 0.0
	if rabbit.daze_time <= 0.1:
		return 0.0
	match rabbit.phase_name():
		"RELAXED":
			return 0.04
		"SLIDING":
			return 0.10
		"EDGE":
			return 0.26
		"CRITICAL":
			return 0.42
	return 0.0


func rabbit_wobble_px() -> float:
	if rabbit.daze_time <= 0.1:
		return 0.0
	match rabbit.phase_name():
		"RELAXED":
			return 1.5
		"SLIDING":
			return 2.5
		"EDGE":
			return 5.0
		"CRITICAL":
			return 8.0
	return 0.0


func turtle_tilt() -> float:
	if turtle.accident:
		return 0.0
	if turtle.daze_time <= 0.1:
		return 0.0
	match turtle.phase_name():
		"RELAXED":
			return 0.02
		"SINKING":
			return 0.05
		"DEEP":
			return 0.12
		"CRITICAL":
			return 0.22
	return 0.0


func _draw_turtle() -> void:
	var pos: Vector2 = turtle.position
	if turtle.speed > 250.0:
		for i in 3:
			var y := pos.y - 24.0 + i * 22.0
			draw_line(Vector2(pos.x - 90.0 - i * 18.0, y),
				Vector2(pos.x - 50.0 - i * 18.0, y),
				Color(0.75, 1.0, 1.0, 0.55), 4.0)
	# 壳画成 92x56 的椭圆，和 96x56 的碰撞体对齐，避免“看着撞了却没判”。
	# 失控时整只侧倾 + 缓慢左右摇：前两段只有一点倾斜，看得到“不太稳”，
	# 临界时倾到 0.22 rad 并来回摇，读到“要翻了”。
	var tilt: float = turtle_tilt()
	if tilt > 0.0:
		tilt += sin(Time.get_ticks_msec() * 0.0024) * tilt * 0.5
	if turtle.accident:
		# 翻肚皮后来回晃两下（幅度随翻完程度增大）：喜剧感靠“晃”，不靠拉长演出。
		tilt += sin(_accident_t * 7.0) * 0.14
	var shell := PackedVector2Array()
	for i in 28:
		var a := TAU * float(i) / 28.0
		shell.append(pos + Vector2(cos(a) * 46.0, sin(a) * 28.0).rotated(tilt))
	draw_colored_polygon(shell, Color(0.25, 0.6, 0.3))
	draw_circle(pos + Vector2(0, -6).rotated(tilt), 27.0, Color(0.55, 0.8, 0.35))
	draw_circle(pos + Vector2(40, -6).rotated(tilt), 14.0, Color(0.4, 0.7, 0.3))
	draw_circle(pos + Vector2(44, -10).rotated(tilt), 3.0, Color(0.05, 0.1, 0.08))
	if turtle.accident:
		# 翻肚皮：浅色肚皮盖住壳面，四肢朝天，头被压在下面。
		# 0.6 s 内从侧翻过渡到全翻，先“出事”再定格，不做瞬切。
		var flip := clampf(_accident_t / 0.6, 0.0, 1.0)
		draw_colored_polygon(shell, Color(0.93, 0.88, 0.72).lerp(
			Color(0.25, 0.6, 0.3), 1.0 - flip))
		for i in 4:
			var lx := -30.0 + i * 20.0
			var ly := -20.0 - 12.0 * flip
			draw_circle(pos + Vector2(lx, ly), 7.0, Color(0.4, 0.7, 0.3))
		draw_circle(pos + Vector2(42, 6), 11.0, Color(0.4, 0.7, 0.3))
		draw_line(pos + Vector2(-14, -16), pos + Vector2(-2, -4),
			Color(1, 0.2, 0.2), 4.0)
		draw_line(pos + Vector2(-2, -16), pos + Vector2(-14, -4),
			Color(1, 0.2, 0.2), 4.0)
	# 只有真有失衡/事故/被浪打湿时才冒状态字；待命不再显示 Zzz（不是在睡觉）。
	if turtle.accident or turtle.daze_time > 0.1 or turtle.dunk_timer > 0.0:
		var color := Color(0.9, 0.9, 1.0)
		match turtle.phase_name():
			"SINKING":
				color = Color(1.0, 0.82, 0.3)
			"DEEP":
				color = Color(1.0, 0.6, 0.25)
			"CRITICAL":
				var pulse := 0.55 + 0.45 * absf(sin(Time.get_ticks_msec() * 0.006))
				color = Color(1.0, 0.35, 0.3, pulse)
		draw_string(ThemeDB.fallback_font, pos + Vector2(38, -58),
			_turtle_phase_text(),
			HORIZONTAL_ALIGNMENT_LEFT, -1, 17, color)


func _draw_rabbit() -> void:
	var pos: Vector2 = rabbit.position
	var crouching: bool = rabbit.state == "CROUCHING"
	var radius := 15.0 if crouching else 22.0
	# 失衡预警：原地晃（不给位移），越往后晃得越大、身体越往后仰。
	var lean: float = rabbit_lean()
	var sway: float = sin(Time.get_ticks_msec() * 0.009) * rabbit_wobble_px()
	var body_pos := pos + Vector2(sway, 0.0)
	if lean > 0.01 and not crouching and rabbit.state in ["RIDING", "RELAXED",
			"SLIDING", "EDGE", "CRITICAL"]:
		draw_set_transform(body_pos, -lean, Vector2.ONE)
		draw_circle(Vector2.ZERO, radius, Color(0.95, 0.95, 0.95))
		draw_rect(Rect2(Vector2(-14, -radius - 40), Vector2(9, 40)),
			Color(0.95, 0.95, 0.95))
		draw_rect(Rect2(Vector2(5, -radius - 40), Vector2(9, 40)),
			Color(0.95, 0.95, 0.95))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		pos = body_pos
	else:
		draw_circle(body_pos, radius, Color(0.95, 0.95, 0.95))
		pos = body_pos
	if rabbit.state == "FALLING_WATER":
		# 落水翻滚：耳朵绕着脑袋转，配 X 眼和水花圈，一秒内看懂“兔子栽水里了”。
		var ang := _accident_t * 9.0
		for i in 2:
			var side := -1.0 if i == 0 else 1.0
			var base := pos + Vector2(side * 9.0, 0)
			draw_line(base, base + Vector2(cos(ang + side), sin(ang + side)) * 40.0,
				Color(0.95, 0.95, 0.95), 8.0)
		draw_line(pos + Vector2(-9, -7), pos + Vector2(-1, 1), Color(0.25, 0.3, 0.35), 3.0)
		draw_line(pos + Vector2(-1, -7), pos + Vector2(-9, 1), Color(0.25, 0.3, 0.35), 3.0)
		draw_line(pos + Vector2(1, -7), pos + Vector2(9, 1), Color(0.25, 0.3, 0.35), 3.0)
		draw_line(pos + Vector2(9, -7), pos + Vector2(1, 1), Color(0.25, 0.3, 0.35), 3.0)
	elif crouching:
		# 趴下时耳朵折平，视觉上不再顶到横梁。
		draw_rect(Rect2(pos + Vector2(-16, -radius - 4), Vector2(14, 6)),
			Color(0.9, 0.9, 0.9))
		draw_rect(Rect2(pos + Vector2(2, -radius - 4), Vector2(14, 6)),
			Color(0.9, 0.9, 0.9))
	elif lean <= 0.01:
		# 站姿且没失衡：竖直耳朵。失衡时上面已经按倾斜姿态画过了。
		draw_rect(Rect2(pos + Vector2(-14, -radius - 40), Vector2(9, 40)),
			Color(0.95, 0.95, 0.95))
		draw_rect(Rect2(pos + Vector2(5, -radius - 40), Vector2(9, 40)),
			Color(0.95, 0.95, 0.95))

	if rabbit.state == "SHOWTIME":
		var dir := Vector2(cos(rabbit.showtime_spin), sin(rabbit.showtime_spin))
		draw_line(pos, pos + dir * 34.0, Color(1.0, 0.8, 0.2), 5.0)
		if rabbit.showtime_pose:
			draw_line(pos + Vector2(-12, -6), pos + Vector2(-26, -34),
				Color(0.95, 0.95, 0.95), 5.0)
			draw_line(pos + Vector2(12, -6), pos + Vector2(26, -34),
				Color(0.95, 0.95, 0.95), 5.0)
		draw_string(ThemeDB.fallback_font, pos + Vector2(-48, -58), "720!",
			HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1.0, 0.85, 0.25))

	# 世界里的“抓地%”条删掉：只保留姿态，失衡数值由 HUD 在真的有风险时显示。
	# 站立/待命时画两只小爪扣住壳，读作“抓紧”，不是发呆。
	if rabbit.state == "RIDING" and mount.state == "RIDING" and not turtle.leap_active:
		draw_circle(pos + Vector2(-11, radius + 2), 4.0, Color(0.9, 0.9, 0.9))
		draw_circle(pos + Vector2(11, radius + 2), 4.0, Color(0.9, 0.9, 0.9))
	if rabbit.state == "STUNNED":
		for i in 3:
			var a := TAU * i / 3.0 + 0.5
			draw_circle(pos + Vector2(cos(a), sin(a)) * 34.0, 4.0,
				Color(1.0, 0.9, 0.3))
	if rabbit.state == "PASSED_OUT":
		draw_line(pos + Vector2(-10, -10), pos + Vector2(-2, -2), Color(0.3, 0.3, 0.3), 3.0)
		draw_line(pos + Vector2(-2, -10), pos + Vector2(-10, -2), Color(0.3, 0.3, 0.3), 3.0)
		draw_line(pos + Vector2(2, -10), pos + Vector2(10, -2), Color(0.3, 0.3, 0.3), 3.0)
		draw_line(pos + Vector2(10, -10), pos + Vector2(2, -2), Color(0.3, 0.3, 0.3), 3.0)

	if mount.state in ["RESCUING", "RESCUE_ACTIVE"] \
			and GameManager.accident_state in ["RABBIT_SLIP", "RABBIT_WATER"]:
		# 水花圈 + 溅点：事故是“落水”不是“消失”，玩家能看见兔子还在水里。
		for i in 3:
			var rr := 16.0 + fmod(_accident_t * 70.0 + i * 24.0, 66.0)
			var alpha := clampf(1.0 - rr / 92.0, 0.0, 0.55)
			draw_arc(pos + Vector2(0, 18), rr, 0, TAU, 32,
				Color(0.75, 0.95, 1.0, alpha), 3.0)
		for i in 4:
			var ang2 := TAU * float(i) / 4.0 + _accident_t * 2.0
			draw_circle(pos + Vector2(cos(ang2), sin(ang2))
				* (24.0 + 22.0 * _accident_t), 3.0, Color(0.9, 1.0, 1.0, 0.5))

	if GameManager.pickup_window:
		draw_arc(turtle.get_mount_point(), 82.0, 0, TAU, 48,
			Color(0.4, 1.0, 0.6), 4.0)
		draw_string(ThemeDB.fallback_font,
			turtle.get_mount_point() + Vector2(-42, -96), Locale.t("hint.pickup"),
			HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0.4, 1.0, 0.6))


func _draw_control_ring() -> void:
	var color := Color(1.0, 0.9, 0.25, 0.9)
	if GameManager.current_control == "turtle":
		draw_arc(turtle.position, 62.0, 0, TAU, 48, color, 5.0)
	else:
		draw_arc(rabbit.position, 36.0, 0, TAU, 36, color, 4.0)


func _draw_hitboxes() -> void:
	for g in hazard_groups:
		var group: Dictionary = g
		for r in group["rects"]:
			draw_rect(r, Color(1.0, 0.2, 0.2, 0.8), false, 2.0)
	draw_rect(turtle.get_body_rect(), Color(0.2, 1.0, 1.0, 0.9), false, 2.0)
	draw_rect(rabbit.get_body_rect(), Color(0.2, 1.0, 0.5, 0.9), false, 2.0)


func _capture_after(seconds: float, file_name: String) -> void:
	await get_tree().create_timer(seconds).timeout
	_save_shot(file_name)
	get_tree().quit(0)


## 窗口化真人键位测试用：不注入任何按键，只在两个时刻截屏。
## 1.95 s 是接住窗口内，4.05 s 是未接住后的有限恢复。
func _capture_rescue(file_name: String) -> void:
	var args := OS.get_cmdline_user_args()
	if "--rescue-demo-catch" in args:
		# 窗口化 + 引擎内输入代理：不是 OS 级真实按键（本机 SendInput 被系统拒绝）。
		await get_tree().create_timer(1.0).timeout
		Input.action_press("down")
		await get_tree().create_timer(0.9).timeout
		_save_shot(file_name)
		Input.action_release("down")
		await get_tree().create_timer(0.4).timeout
		get_tree().quit(0)
		return
	if "--rescue-demo-miss" in args:
		await get_tree().create_timer(3.4).timeout
		_save_shot(file_name)
		await get_tree().create_timer(0.7).timeout
		_save_shot(file_name.get_basename() + "_late.png")
		get_tree().quit(0)
		return
	await get_tree().create_timer(1.95).timeout
	_save_shot(file_name)
	await get_tree().create_timer(2.10).timeout
	_save_shot(file_name.get_basename() + "_late.png")
	get_tree().quit(0)


func _capture_pause(file_name: String) -> void:
	await get_tree().create_timer(0.6).timeout
	GameManager.toggle_pause()
	await get_tree().create_timer(0.3).timeout
	_save_shot(file_name)
	get_tree().quit(0)


func _arg_after(args: PackedStringArray, flag: String, fallback: String) -> String:
	var i := args.find(flag)
	if i >= 0 and i + 1 < args.size() and not args[i + 1].begins_with("--"):
		return args[i + 1]
	return fallback


func _capture_showtime() -> void:
	await get_tree().create_timer(0.4).timeout
	turtle.position = Vector2(5100.0, surface_ref())
	turtle.speed = 220.0
	await get_tree().create_timer(0.2).timeout
	start_showtime()
	await get_tree().create_timer(0.45).timeout
	_save_shot(_arg_after(OS.get_cmdline_user_args(), "--capture-showtime", "stage2_showtime.png"))
	get_tree().quit(0)


func _capture_boost() -> void:
	await get_tree().create_timer(0.3).timeout
	turtle.position = Vector2(2700.0, surface_ref())
	turtle.speed = 380.0
	await get_tree().create_timer(0.4).timeout
	_save_shot("stage2_boost.png")
	get_tree().quit(0)


func _capture_accident() -> void:
	await get_tree().create_timer(0.4).timeout
	turtle.position = Vector2(1290.0, surface_ref())
	await get_tree().create_timer(0.4).timeout
	_save_shot(_arg_after(OS.get_cmdline_user_args(), "--capture-accident", "stage2_accident.png"))
	get_tree().quit(0)


## 乌龟跃起：停在鲨鱼前，受控触发一次，0.5 s 时在上升段。
func _capture_leap(file_name: String) -> void:
	await get_tree().create_timer(0.4).timeout
	test_disable_hazards = true
	GameManager.set_control("turtle")
	turtle.position = Vector2(6150.0, surface_ref())
	await get_tree().create_timer(0.15).timeout
	turtle.start_leap()
	await get_tree().create_timer(0.5).timeout
	_save_shot(file_name)
	get_tree().quit(0)


## 原型段截图：五类障碍各一张 + 组合漂浮物的完整序列 + F3 判定框。
## 不关判定，跑不通就会在截图里看到事故——这是证据，不是摆拍。
func _capture_proto(prefix: String) -> void:
	await get_tree().create_timer(0.4).timeout
	GameManager.state = GameManager.GameState.RUNNING
	var shots := [
		["bird", Vector2(1180.0, surface_ref())],
		["rock", Vector2(2380.0, surface_ref())],
		["beam", Vector2(3580.0, surface_ref())],
		["gate", Vector2(4780.0, surface_ref())],
		["shark", Vector2(5980.0, surface_ref())],
		["log", Vector2(7260.0, surface_ref())],
	]
	for s in shots:
		turtle.position = s[1]
		turtle.speed = 0.0
		await get_tree().create_timer(0.3).timeout
		_save_shot("%s_%s.png" % [prefix, s[0]])
	# 同一位置再拍一张 F3：每类障碍的兔子/乌龟判定框与上下安全通道。
	debug_mode = true
	show_hitboxes = true
	for s in shots:
		turtle.position = s[1]
		turtle.speed = 0.0
		await get_tree().create_timer(0.3).timeout
		_save_shot("%s_debug_%s.png" % [prefix, s[0]])
	debug_mode = false
	show_hitboxes = false
	# 组合漂浮物的完整序列：先跳、再换乌龟、再下潜、最后接回。
	test_disable_hazards = true
	turtle.speed = 220.0
	GameManager.set_control("rabbit")
	turtle.position = Vector2(7400.0, surface_ref())
	await get_tree().create_timer(0.1).timeout
	Input.action_press("up")
	await get_tree().physics_frame
	await get_tree().physics_frame
	Input.action_release("up")
	await get_tree().create_timer(0.45).timeout
	_save_shot("%s_combo_1_jump.png" % prefix)
	GameManager.set_control("turtle")
	Input.action_press("down")
	await get_tree().create_timer(0.8).timeout
	_save_shot("%s_combo_2_dive.png" % prefix)
	await get_tree().create_timer(0.9).timeout
	_save_shot("%s_combo_3_land.png" % prefix)
	Input.action_release("down")
	# F3：判定框 + 上下安全通道。
	debug_mode = true
	show_hitboxes = true
	turtle.position = Vector2(7260.0, surface_ref())
	await get_tree().create_timer(0.5).timeout
	_save_shot("%s_debug.png" % prefix)
	get_tree().quit(0)


## F3 调试层：障碍 ID/类型/动作、判定框、触发距离、危险深度线一次看全。
func _capture_debug(file_name: String) -> void:
	await get_tree().create_timer(0.4).timeout
	test_disable_hazards = true
	debug_mode = true
	show_hitboxes = true
	turtle.position = Vector2(1050.0, surface_ref())
	await get_tree().create_timer(0.2).timeout
	_save_shot(file_name)
	get_tree().quit(0)


## Phase H：鲨鱼判定框与画法对齐取证。把乌龟放在第一条鲨鱼前 300 px，
## 打开 show_hitboxes：红框上沿必须贴着鱼头顶，不再有 30 px 空白。
func _capture_shark(file_name: String) -> void:
	await get_tree().create_timer(0.4).timeout
	test_disable_hazards = true
	debug_mode = true
	show_hitboxes = true
	turtle.position = Vector2(6900.0, surface_ref())
	await get_tree().create_timer(0.2).timeout
	_save_shot(file_name)
	get_tree().quit(0)


## M 门槛① 的可读性证据：岩/梁的水下反下潜段必须看得见。
## 窗口化运行 + 引擎内输入代理（不是 OS 级真实按键）：控制乌龟、按住下潜，
## 在兔子撞上水下那段的瞬间截屏。rock1 2400 / beam1 3700。
func _capture_dive_block(which: String) -> void:
	await get_tree().create_timer(0.4).timeout
	var x0 := 2400.0 if which == "rock" else 3700.0
	GameManager.set_control("turtle")
	turtle.position = Vector2(x0 - 300.0, surface_ref())
	Input.action_press("down")
	await get_tree().create_timer(1.7).timeout
	_save_shot("phase-m_%s_block.png" % which)
	Input.action_release("down")
	get_tree().quit(0)


## 待命稳定性截图：控制乌龟，兔子待命，壳应停在巡航水深、兔子不滑。
func _capture_standby(file_name: String) -> void:
	await get_tree().create_timer(0.4).timeout
	test_disable_hazards = true
	GameManager.set_control("turtle")
	turtle.position = Vector2(5200.0, surface_ref())
	await get_tree().create_timer(2.0).timeout
	_save_shot(file_name)
	get_tree().quit(0)


## 失衡姿态证据（Phase G 后）：daze 封顶 3.6，只做短硬直/姿态，不定罪。
## 旧五段的 EDGE / CRITICAL（6.0 / 8.4）已不可达，对应旧截图已移入 _attic。
func _capture_imbalance() -> void:
	await get_tree().create_timer(0.35).timeout
	test_disable_hazards = true
	GameManager.has_shifted = true
	turtle.position = Vector2(4700.0, surface_ref())
	var poses := [["relaxed", 1.0], ["sliding", 2.5], ["capped", Tuning.DAZE_CAP]]
	for p in poses:
		# 每帧重新钉住：viewport 截图取的是上一帧画好的 HUD，
		# 只设一次会拍到上一档的数（capped 会被拍成 26%）。
		for i in 20:
			rabbit.daze_time = p[1]
			turtle.daze_time = p[1]
			await get_tree().process_frame
		_save_shot("stage4_poseg_%s.png" % p[0])
	get_tree().quit(0)


## Phase G 证据：一次乌龟浪击、一次兔子碰撞、第三格联合事故、演出后复位。
## 用现有的碰撞入口重放，HUD 和姿态都走真实主流程；不注入 OS 按键。
func _capture_penalty(prefix: String) -> void:
	await get_tree().create_timer(0.35).timeout
	test_disable_hazards = true
	GameManager.total_score = 1000
	turtle.position = Vector2(4700.0, surface_ref())
	turtle.speed = 0.0
	await get_tree().create_timer(0.2).timeout
	_turtle_contact("demo_wave")
	await get_tree().create_timer(0.25).timeout
	print("PENALTY DEMO 1 wave score=%d meter=%d state=%s" % [
		GameManager.total_score, GameManager.bro_meter, GameManager.accident_state])
	_save_shot("%s_hit_turtle.png" % prefix)
	# 等 dunk 结束、底部提示自然过期，再让兔子撞一下：
	# 两种事故表现要在同一组图里可比，且互不串提示。
	await get_tree().create_timer(3.0).timeout
	_rabbit_contact()
	await get_tree().create_timer(0.15).timeout
	print("PENALTY DEMO 2 rabbit score=%d meter=%d state=%s log=%s" % [
		GameManager.total_score, GameManager.bro_meter, GameManager.accident_state,
		str(GameManager.score_log.slice(-4))])
	_save_shot("%s_hit_rabbit.png" % prefix)
	await get_tree().create_timer(Tuning.STUN_TIME + 0.35).timeout
	_turtle_contact("demo_wave_2")
	# 联合演出 1.4 s；0.9 s 时闪白已退，画面能看清“3/3 + 联合惩罚”。
	await get_tree().create_timer(0.9).timeout
	print("PENALTY DEMO 3 full score=%d meter=%d state=%s pending=%s" % [
		GameManager.total_score, GameManager.bro_meter, GameManager.accident_state,
		GameManager.bro_joint_pending])
	_save_shot("%s_meter_full.png" % prefix)
	await get_tree().create_timer(1.2).timeout
	_save_shot("%s_recovered.png" % prefix)
	get_tree().quit(0)


## 兔子落水演出：耳朵打转 + X 眼 + 水花圈，0.5 s 时定格。
func _capture_fall(file_name: String) -> void:
	await get_tree().create_timer(0.35).timeout
	hazard_cooldown = 0.0
	_trigger_accident("RABBIT_WATER")
	await get_tree().create_timer(0.5).timeout
	_save_shot(file_name)
	get_tree().quit(0)


## 乌龟翻肚皮演出：0.6 s 从侧翻过渡到全翻，0.8 s 时定格（四肢朝天、X 眼）。
func _capture_flip(file_name: String) -> void:
	await get_tree().create_timer(0.35).timeout
	hazard_cooldown = 0.0
	_trigger_accident("TURTLE_REEF")
	await get_tree().create_timer(0.8).timeout
	_save_shot(file_name)
	get_tree().quit(0)


func _save_shot(file_name: String) -> void:
	var dir := ProjectSettings.globalize_path("res://screenshots")
	DirAccess.make_dir_recursive_absolute(dir)
	var image := get_viewport().get_texture().get_image()
	var path := dir.path_join(file_name)
	image.save_png(path)
	print("CAPTURE ", path)
