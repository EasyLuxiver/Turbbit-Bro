extends Node2D
## 乌龟：自动巡航 / 加速 / 下潜 / 上浮 / 神游下沉。
## 失控按 GDD 5.6 分三段：失去动力（DAZED）→ 缓慢下沉（SINKING）→
## 接近危险深度（DEEP）→ 事故。位置与时间同时参与判断。

const Tuning = preload("res://scripts/systems/tuning.gd")
const SURFACE_Y := 300.0
const DEEP_Y := 760.0
const BASE_SPEED := 220.0
const BOOST_SPEED := 330.0
const VERTICAL_SPEED := 180.0
const BODY_SIZE := Vector2(96, 56)

var speed := BASE_SPEED
## 区域基础速度：由 race 按当前赛段写入，220 → 240 → 260。
var base_speed := BASE_SPEED
var state := "CRUISING"
var accident := false
var daze_time := 0.0
var control_hold := 0.0
var _sink_speed := 0.0
## 冲浪板模型的垂直速度（px/s，正=下沉）。受控时由浮力驱动，失控时由下沉驱动。
var _vy := 0.0
## 兔子滞空期间壳不沉：兔子只是跳起来了，不是不管乌龟。
var hold_depth := false
## 主动跃起（↑）：带动整组向上跳，躲水下攻击。一次性，落回巡航水深。
var leap_active := false
var leap_timer := 0.0
var leap_cooldown := 0.0
var leap_count := 0
## 主动下潜（↓）：按住下到巡航水深以下，松开/通过后自动上浮。
## 不是事故状态，也不累积失衡。
var diving := false
## 被浪拍中后整组短暂没入水下：氧气消耗因此有真实来源。
var dunk_timer := 0.0


func reset(start_pos: Vector2) -> void:
	position = start_pos
	speed = BASE_SPEED
	base_speed = BASE_SPEED
	state = "CRUISING"
	accident = false
	daze_time = 0.0
	control_hold = 0.0
	_sink_speed = 0.0
	_vy = 0.0
	leap_active = false
	leap_timer = 0.0
	leap_cooldown = 0.0
	leap_count = 0
	diving = false
	dunk_timer = 0.0


func tick(delta: float, controlled: bool, boosting: bool, vertical: float,
		auto_cruise: bool, boost_target: float = BOOST_SPEED) -> void:
	if accident:
		speed = move_toward(speed, 0.0, 480.0 * delta)
		position.x += speed * delta
		return

	if Tuning.SURFBOARD_PHYSICS:
		_tick_surfboard(delta, controlled, boosting, vertical, auto_cruise, boost_target)
		position.x += speed * delta
		return

	if controlled or auto_cruise:
		if auto_cruise:
			# 开局/事故宽限：完整重置，避免第一次 SHIFT 前和恢复期立刻下沉。
			daze_time = 0.0
			control_hold = 0.0
			_sink_speed = 0.0
		else:
			# 连续控制满 0.5 s 才开始恢复；已经下沉的深度和计时不因切换清零。
			control_hold += delta
			if control_hold >= Tuning.CONTROL_RECOVER_DELAY:
				daze_time = maxf(daze_time - Tuning.CONTROL_RECOVER_RATE * delta, 0.0)
		var target := boost_target if (controlled and boosting) else base_speed
		var accel := 420.0 if target > speed else 300.0
		speed = move_toward(speed, target, accel * delta)

		var vy := vertical * VERTICAL_SPEED if controlled else 0.0
		if position.y <= SURFACE_Y and vy < 0.0:
			vy = 0.0
		position.y = clampf(position.y + vy * delta, SURFACE_Y, DEEP_Y)

		if controlled and position.y > SURFACE_Y + 2.0:
			state = "DIVING" if vy >= 0.0 else "SURFACING"
		elif controlled:
			state = "BOOSTING" if boosting else "CRUISING"
		else:
			state = "CRUISING"
		# 受控时保留 _sink_speed：再次失控会从当前下沉速度继续，而不是免费的归零。
	else:
		control_hold = 0.0
		daze_time += delta
		if daze_time < Tuning.RELAX_TIME:
			# 提示期：失去推进，但还稳在水面，不动位置。
			state = "DAZED"
			speed = move_toward(speed, 140.0, 100.0 * delta)
			_sink_speed = 0.0
		elif daze_time < Tuning.SINK_EDGE_TIME:
			# 进行期：缓慢下沉。
			state = "SINKING"
			speed = move_toward(speed, 90.0, 60.0 * delta)
			_sink_speed = move_toward(_sink_speed, 50.0, 40.0 * delta)
			position.y = minf(position.y + _sink_speed * delta, DEEP_Y)
		elif daze_time < Tuning.SINK_DANGER_TIME:
			# 危险期：接近危险深度。
			state = "DEEP"
			speed = move_toward(speed, 50.0, 40.0 * delta)
			_sink_speed = move_toward(_sink_speed, 120.0, 50.0 * delta)
			position.y = minf(position.y + _sink_speed * delta, DEEP_Y)
		else:
			state = "DANGER"
			speed = move_toward(speed, 40.0, 30.0 * delta)
			position.y = minf(position.y + 140.0 * delta, DEEP_Y)

	position.x += speed * delta


## 冲浪板模型：没有手动上下、没有速度档位。
## 永远自动巡航；受控时进加速带自动提速。待命保持巡航水深，不下沉。
## 失衡只由事件（浪击/撞击/特殊动作失败）累积，受控稳定操控时回落。
func _tick_surfboard(delta: float, controlled: bool, boosting: bool,
		vertical: float, _auto_cruise: bool, boost_target: float) -> void:
	leap_cooldown = maxf(leap_cooldown - delta, 0.0)
	if dunk_timer > 0.0:
		dunk_timer = maxf(dunk_timer - delta, 0.0)

	# 速度：自动巡航；加速带只在操控乌龟时生效，不需要按键。
	var target := base_speed
	if controlled and boosting:
		target = boost_target
	var accel := 420.0 if target > speed else 300.0
	speed = move_toward(speed, target, accel * delta)

	# 失衡：受控稳定操控 0.5 s 后按 2.5/s 收回；待命冻结（不涨也不掉）。
	if controlled:
		control_hold += delta
		if control_hold >= Tuning.CONTROL_RECOVER_DELAY:
			daze_time = maxf(daze_time - Tuning.CONTROL_RECOVER_RATE * delta, 0.0)
	else:
		control_hold = 0.0

	# 主动跃起：整组上抛，兔子被带动，不需要重复跳。结束后回巡航水深。
	if leap_active:
		leap_timer += delta
		var p := clampf(leap_timer / Tuning.LEAP_TIME, 0.0, 1.0)
		position.y = Tuning.NEUTRAL_DEPTH - sin(PI * p) * Tuning.LEAP_HEIGHT
		_vy = -cos(PI * p) * PI * Tuning.LEAP_HEIGHT / Tuning.LEAP_TIME
		speed = base_speed
		diving = false
		state = "LEAPING"
		if p >= 1.0:
			leap_active = false
			leap_timer = 0.0
			position.y = Tuning.NEUTRAL_DEPTH
			_vy = 0.0
			state = "CRUISING"
		return

	# 目标深度：默认巡航；按住 ↓ 时下潜；被撞后短暂强制更深。
	var want_y := Tuning.NEUTRAL_DEPTH
	diving = controlled and vertical > 0.0 and dunk_timer <= 0.0
	if diving:
		want_y = Tuning.NEUTRAL_DEPTH + Tuning.DIVE_DEPTH
	if dunk_timer > 0.0:
		want_y = Tuning.NEUTRAL_DEPTH + Tuning.DUNK_DEPTH
	if vertical < 0.0:
		# 紧急上浮（氧气耗尽）：强制目标改成水面，但仍然按加速度移动。
		want_y = SURFACE_Y
	var sink_speed := Tuning.DIVE_SINK_SPEED if diving else Tuning.BUOY_SINK_SPEED
	var vy_target := clampf((want_y - position.y) * Tuning.BUOY_GAIN,
		-Tuning.DIVE_RISE_SPEED, sink_speed)
	_vy = move_toward(_vy, vy_target, Tuning.DIVE_ACCEL * delta)
	position.y = clampf(position.y + _vy * delta, SURFACE_Y, DEEP_Y)

	if dunk_timer > 0.0:
		state = "DUNKED"
	elif daze_time > 0.01:
		state = "RECOVERING" if controlled else phase_name()
	elif absf(Tuning.NEUTRAL_DEPTH - position.y) < 2.0:
		state = "BOOSTING" if (controlled and boosting) else "CRUISING"
	elif _vy < 0.0:
		state = "SURFACING"
	else:
		state = "DIVING"


## 主动跃起：整组上抛，躲水下攻击。一次性，不是档位；冷却很短，防止连按叠跳。
func can_leap() -> bool:
	return not accident and not leap_active and leap_cooldown <= 0.0


func start_leap() -> bool:
	if not can_leap():
		return false
	leap_active = true
	leap_timer = 0.0
	leap_cooldown = Tuning.LEAP_TIME + Tuning.LEAP_COOLDOWN
	leap_count += 1
	dunk_timer = 0.0
	return true


func start_dunk() -> void:
	dunk_timer = Tuning.DUNK_TIME


## 事件驱动的失衡。浪击、撞击、特殊动作失败走这里，待命时间不走这里。
## Phase G：只做短硬直/姿态，封顶在 DAZE_CAP；持续风险由 BRO METER 记。
func add_imbalance(amount: float) -> void:
	if amount <= 0.0:
		return
	daze_time = minf(daze_time + amount, Tuning.DAZE_CAP)
	state = phase_name()


func phase_name() -> String:
	if daze_time < Tuning.RELAX_TIME:
		return "RELAXED"
	if daze_time < Tuning.SINK_EDGE_TIME:
		return "SINKING"
	if daze_time < Tuning.SINK_CRITICAL_TIME:
		return "DEEP"
	return "CRITICAL"


func phase_label() -> String:
	match phase_name():
		"RELAXED":
			return "NO POWER"
		"SINKING":
			return "SINKING"
		"DEEP":
			return "TOO DEEP"
		_:
			return "CRITICAL"


func is_in_danger() -> bool:
	return daze_time >= Tuning.SINK_DANGER_TIME


func is_at_surface() -> bool:
	if Tuning.SURFBOARD_PHYSICS:
		# 被浪打湿没入水下时接不住兔子；巡航/跃浪高度都接得住。
		# 120 = 浮出带（BRO DIVE 里壳还在上浮时也算“在水面”）。
		return position.y <= Tuning.NEUTRAL_DEPTH + Tuning.PICKUP_SURFACE_MARGIN
	return position.y <= SURFACE_Y + 40.0


## 壳是否正在上浮：接人窗口据此放宽（见 mount_controller.can_pickup）。
func is_rising() -> bool:
	return _vy < -1.0


func get_mount_point() -> Vector2:
	return position + Vector2(0, -58)


func get_body_rect() -> Rect2:
	return Rect2(position - BODY_SIZE * 0.5, BODY_SIZE)
