# LONGRUN_STATE — TBB-LONGRUN-PLAYABILITY-01 / -02

STATUS: RUNNING
LAST_UPDATED: 2026-11-12 19:11
NEXT: 追加任务 `TBB-LONGRUN-PLAYABILITY-02` 的 §七-10、§七-11 已完成
（`PHASE-U-FULL-RUN.md`：中英文各两圈 55/55、0 事故、stderr 0 行、`best.json` 还原）。
下一轮**先改 Z1 开场 0–30 s 空跑**（Phase S/T 连续两阶段同一处），
再等制作人真人试玩；所有手感/难度结论仍 `NOT TESTED`。
**不进入 STAGE 5，不宣布最终完成。**
`-01` 的全部状态与证据保留在下方，不覆盖；`-02` 的进度见文末「追加任务 -02」一节。

## 任务

- 编号：TBB-LONGRUN-PLAYABILITY-01
- 目标：把 Turbbit Bro! 做成完整、欢乐、易上手、有操作深度、值得重复游玩的灰盒；
  最终交制作人人工验收。
- 硬约束：`STAGE=4`，禁止推进 STAGE 5；真人试玩一律 `NOT TESTED`；
  不跑 `../LESSONS/CHECKS/preflight.py`；素材继续冻结。
- 完整指令：`docs/reports/longrun/MISSION.md`（原文）。

## 版本与工作区

- 引擎：Godot 4.7 stable（`D:/Godot_v4.7-stable_win64_console.exe`）。
- `docs/STAGE.md`：`STAGE=4`。
- Git 根：`D:/GAMESTUDIO`，HEAD `4448151`；**`TURBBIT/` 整体未被跟踪**
  （`git status --short -- TURBBIT` 只有 `?? TURBBIT/`，`git ls-files TURBBIT` 为 0）。
  因此没有可回退的提交基线。
- 开工基线快照：`docs/reports/longrun/baseline-2026-11-12-0205.zip`
  （scripts / scenes / project.godot / STAGE / STAGE-4 文档 / 解法矩阵，约 260 KB）。
  任何回退先取这个 zip，不要依赖 git。
- 玩家纪录：`best.json` 现为
  `{"score_model":2,"best_time":296.63,"best_accidents":0,"best_score":-1,"best_streak":54}`。
  自动跑写过的测试纪录已还原；测试写入前的副本在
  `%APPDATA%/Godot/app_userdata/Turbbit Bro!/best.json.testrun-20261112.bak`。

## 已完成阶段

- A 启动前检查：已读 STAGE / STAGE-4.md / STAGE-4-SPACE.md / 最新 QC / 最新回归；
  已查进程；已建任务目录、状态文件、恢复提示、基线快照、提醒脚本。
  Windows 任务 `TURBBIT-Longrun-Reminder` 已注册到 `2026-11-12 07:00 +08:00`
  （Interactive + WakeToRun），脚本已用 `-Test` 直接跑通（退出码 0）；
  详见 `REMINDER.md`。07:00 的真实触发已观测到（`reminder.log`：`07:00:02 TEST=False
  status=RUNNING lock=RUNNING pid=7972`，07:01:03 弹窗被确认）；但当时的锁是**陈旧锁**
  ——实际工作在 04:13 就因脚本解析错误挂了，锁没删。教训：锁文件不能单独当“活着”的证据。
- B 设计方向：已记录，尚未做任何玩法改动。
- C 逐组体验审计：完成，只读。报告 `PHASE-C-AUDIT.md`；细窗数据
  `phase-c-windows.json`；55 行表 `_phase_c_table.md`；截图 `screenshots/phase-c_*.png`。
  核心结论：单乌龟覆盖 44/55；下潜覆盖 38/55；必须 SHIFT 仅 11/55；兔子无唯一解；
  连招第一段窗口 0.14–0.25 s；最长空档 5.91 s；鲨鱼判定上沿有 34 px 隐形带。
- F 主动救援：完成工程验证并接入主流程。报告 `PHASE-F-RESCUE.md`；
  水救数据 `phase-f-rescue.json`、空中对比 `phase-f-rescue-air.json`；
  窗口化截图 `screenshots/rescue_demo_catch.png`、`rescue_demo_miss*.png`。
  选定“下潜接住水面兔子”；`RABBIT_WATER` 不再 1.6 s 自动放回，改为 3.2 s 主动窗口，
  失败 0.8 s 有限回壳；真人 NOT TESTED。本机 OS 键位注入被系统拒绝（SendInput=0），
  窗口化证据是引擎内输入代理，不是真人键位。
- E 连招第二段窗口：完成，只读。报告 `PHASE-E-COMBOS.md`；
  数据 `phase-e-combo-windows.json`；日志 `docs/reports/logs/combo-windows.log`。
  核心结论：BRO DIVE 最佳第二段窗 0.15/0.20/0.25 s（Z1/Z2/Z3），
  自然做法“跳完立刻 SHIFT+↓”成立，犹豫 >0.15 s 会龟撞；
  BRO OLLIE 第二段最早只能从 0.40 s 开始，最佳窗 0.25/0.35/0.30 s，早按必失败。
  两种连招结构都成立；Z1 log1 的 0.15 s 是唯一低于 0.25 s 的完整窗口。
- G 惩罚统一：完成工程验证。报告 `PHASE-G-PENALTY.md`。
  `daze_time` 降为短硬直/姿态，封顶 `DAZE_CAP=3.6`（旧落水线 9.5 的 38%），
  不再由阈值自动触发 `RABBIT_SLIP` / `TURTLE_REEF`；所有有效失误经
  `note_mistake()` 当场记 1 格 + −100，第三格播 1.4 s `BRO_BREAK`，之后复位、
  清格、1.5 s 宽限、本局继续。连续碰撞靠 `hit_groups` 去重。
  新增自检 `stage4_penalty`（37 条）；窗口化截图 `screenshots/phase-g_*.png`。
  真人 NOT TESTED。
- H 三区节奏与障碍空间：完成（证据见 `PHASE-H-ZONE-SPACE.md`）。四处改动：
  ① 审计脚本 `_reset()` 补清 BRO METER（假无解 g=27 的根因，属探针 bug）；
  ② Z1 连招顺序对调：先浮木 BRO DIVE、后高墙 BRO OLLIE，log1 右移 120 px 保住 ≥5 s；
  ③ 高墙墙身 y 206→236（世界 240→270）：起手窗口 wall1 0.136→0.318 s、
  wall2 0.208→0.375 s、wall3 0.192→0.308 s；抬墙楣的假设被实测否掉并回退；
  ④ 鲨鱼画法上沿 `top+34`→`top+4`，与判定框同一条线。
  最终几何矩阵 55/55 有解、0 设计答案缺失、0 条 `passing_schemes` 差异（按区分/种类比较）；
  最终几何 `stage4_metrics` PASS、自动批 10/10 PASS、两圈 55/55×2 0 事故。
  真人 NOT TESTED。
- I HUD / 菜单 / 中英双语：完成自动部分（报告 `PHASE-I-HUD-INTERACTION.md`）。
  真正找到并修掉的是对比度：压在 60% 面板上的灰字 3.81:1、红字 3.59:1、
  失衡 50–80% 档 3.06:1，全部低于 4.5:1。改法只动文字色（`MUTED` 提亮、
  新增 `RED_TEXT`、`_risk_color()` 四档换浅色），`PANEL_BG` 仍是 60%——
  要压到 4.5:1 得把面板调到约 90% 不透明，那是任务书明令避免的。
  改后最差 4.76:1。布局没动（4.17% / 5.28% 本就在 8% 内）。
  新增 `stage4_hud_contrast`、`stage4_hud_layout`；`stage4_hud_priority` 加了实测存活时长；
  `stage4_menu_input` 加了 ENTER 与三张截图。真人 NOT TESTED。
- J 难度 / 舒适度 / 可重复游玩：完成自动部分（报告 `PHASE-J-DIFFICULTY.md`）。
  **零玩法改动**，只加测量工具。结论：55 组最紧容差 0.154 s（shark6/8/9，Z3）、
  最紧反应预算 3.54 s（wall3）、组间最紧空档 3.85 s；7 类障碍在 Z1 全部各教一次，
  提示距障碍 ≥3.72 s（含零输入乱撞、38 次事故的对抗工况）；
  没有单一方案覆盖全程（最高下潜 38/55）。窗口化实跑两圈 55/55、0 事故、0 SCRIPT ERROR。
  新增探针 `stage4_lesson_prompt`；`stage4_solution_audit` 加 `--tolerance`；
  `stage4_combo_windows` 加 `--indices/--out`；离线汇总 `logs/phase-j/summarize.py`。
  真人 NOT TESTED。

## 当前进行中的工作

无。M 门槛 ① 已完成：
- 制作人 2026-11-12 在「加成本 / 收窄几何 / 保持现状」里选了**收窄关卡几何**。
- 做法（零机制改动）：`level_data.gd` 给 `SURFACE_ROCK` / `LOW_BEAM` 各加一段
  水下阻挡（世界 y 402～452）。这段正好罩住“下潜后的兔子身体 402～450”，
  巡航壳 306～362 从上方过、下潜壳 456～512 从下方过，壳不穿模；
  A 类仍只判兔子、趴低仍按状态放行，判定规则一行没改。
- 结果：`dive` 覆盖率 38/55 → **17/55**（只剩 8 个礁门 + 9 只鸟），
  岩 12 + 梁 9 共 21 组下潜全失败；`leap` 27 成为最高单方案；
  55/55 仍有解、设计答案全过；容差扫描逐组不变；窗口化两圈 55/55、0 事故。
- 证据：`PHASE-M-DIVE.md`、`logs/phase-m/`（含 `before/` 备份）、
  `screenshots/phase-m_{rock,beam}_block.png`。

## 下一项可执行任务

M（最终交付门槛）两条硬要求，**都已完成自动层**：
② **PASS（2026-11-12 13:12）**：headless `stage4_penalty` 37/37 ok、
`STAGE4 PENALTY: PASS`、stderr 0 字节；代码上事故只有一条链
`_trigger_accident → note_accident → note_mistake → BRO METER`，`daze_time`
仍封顶 `DAZE_CAP` 只做硬直；`best.json` 跑前备份、跑后逐字节一致。
证据 `docs/reports/logs/phase-m/penalty.log` + `best.before.json`。
① **PASS（2026-11-12 16:45）**：按制作人选择的「收窄关卡几何」完成，
下潜覆盖率 38/55→17/55，21 组岩/梁不再能被下潜绕过。QC `tbb-stage4-dive-dominance`
9/9 pass；证据 `PHASE-M-DIVE.md`、`logs/phase-m/coverage.json`。
**没有改任何机制/数值**，只给两类障碍加了水下段。

自动项到此为止。下一步只剩真人试玩（所有 `NOT_VERIFIED` 的共同缺口），
不得把自动结论当作已验收。

已收口但 `NOT_VERIFIED` 的 QC：`tbb-stage4-difficulty-comfort`（1–6 pass、7 pending）、
`tbb-stage4-hud-interaction`（1–6 pass、7 pending）、
`tbb-stage4-zone-space`（1–6 pass、7 pending）、
`tbb-stage4-penalty`（1–6 pass、7 pending）、
`tbb-longrun-rescue`（1–5 pass、6 pending）、`tbb-stage4-combo-core`（1–10 pass、11 pending）。

## 已知问题与证据

| 问题 | 现状 | 证据 |
|---|---|---|
| 真人试玩 | NOT TESTED；QC 第 11 条 pending | `../LESSONS/CHECKS/qc.py status --task tbb-stage4-combo-core` |
| 只潜覆盖 | **已收窄（Phase M）**：38/55 → 17/55（只剩鸟 9 + 门 8）；岩/梁 21 组下潜全失败，必须跳/趴 | `PHASE-M-DIVE.md`、`logs/phase-m/coverage.json` |
| 最高覆盖单方案 | `leap` 27/55（有时机成本，最紧窗口 0.154 s）；不是按住不放的零成本解 | `logs/phase-m/coverage.json` |
| 真正强制换人 | 11/55（浮木 8/墙 3）；鲨 6 只需乌龟，不用 SHIFT | `PHASE-C-AUDIT.md` §2.1 |
| 兔子无唯一解 | 兔子能过的 30 组都有乌龟替代 | `PHASE-C-AUDIT.md` §2.1 |
| 两套失衡 | **已消除**（Phase G）：daze 封顶 3.6 只做硬直，BRO METER 三格唯一 | `PHASE-G-PENALTY.md` §2 |
| ~~HUD 失衡条封顶 38%~~ | **已修（Phase G）**：分母改为 `DAZE_CAP`，条能走满；文案改“晃动/不稳” | `race.gd` `rabbit_imbalance_pct()`、`PHASE-G-PENALTY.md` §7 |
| 死代码 | `is_falling()` / `can_sink_danger()` 无生产调用者；旧下沉模型留在 `SURFBOARD_PHYSICS=false` 分支 | `grep` 结果、`PHASE-G-PENALTY.md` §7 |
| 总分区分度 | S=8000/9500；分数是按组记账 | `game_manager.gd`、`stage4-metrics` |
| 空档旧数作废 | 组间空档 54 个：最小 3.85 s、中位 4.44 s、最长 5.55 s；开场跑道 4.09 s（x=400→bird1）。无 8.3–8.7 s 空档 | `logs/phase-j/phase-j-summary.json`、`PHASE-C-AUDIT.md` §2.5 |
| 反应 / 容差 / 恢复 | 自动探针全达标：反应 ≥3.54 s、容差 ≥0.154 s、恢复 ≥3.85 s；**不是真人数据** | `logs/phase-j/phase-j-summary.json`、`PHASE-J-DIFFICULTY.md` §3–5 |
| Z3 实际起手时间 | 3.85 s 间距 − 130–235 px 起手 = 2.94–3.35 s | `PHASE-C-AUDIT.md` §2.5 |
| 连招窗口 | 浮木 0.182/0.208/0.231 s；高墙 0.318/0.375/0.308 s（Phase H 后） | `phase-e-combo-windows.phaseh-after.json`、`PHASE-H-ZONE-SPACE.md` §5 |
| 鲨鱼判定上沿 | **已修（Phase H）**：鱼头顶 = 判定框上沿 + 4 px（原 34 px） | `race.gd` SHARK 画法、`screenshots/phase-h_shark.png` |
| 救援未成立 | 已改为主动下潜救援；3.2 s 窗口、失败 0.8 s 回壳 | `PHASE-F-RESCUE.md`、`phase-f-rescue.json` |
| 救援偏宽容 | 2.0 s 内开始下潜都能接住，横向可身后 120 px 接住 | `PHASE-F-RESCUE.md` §6 |
| 窗口化真实键位 | 本机 SendInput 返回 0，OS 注入不可用；窗口化证据是引擎内代理 | `logs/input-injection-sendinput.log` |
| 菜单测试 | headless 鼠标必 FAIL，窗口化 PASS | `stage4-menu-input-rev2-windowed.log` |
| 720p 字号 | **已修（Phase T/U）**：HUD/结算 18 设计；菜单/设置/退出/暂停 14/15/16→18；1280×720 一律 14.4 px 实际（原 10.4–12.8 px），`stage4_menu_input` 5 处断言覆盖 | `PHASE-T-HUD-SCORE.md` §3.5、`PHASE-U-FULL-RUN.md` §2/§6.2、`logs/phase-t/regress/stage4_menu_input.log` |
| HUD 对比度 | **已修（Phase I）**：最差 3.06→4.76:1；面板透明度未动 | `logs/phase-i/contrast.log`、`PHASE-I-HUD-INTERACTION.md` §3 |
| 菜单最高分 | **已修（Phase U）**：纪录行只显示最佳时间 + 最长连击；`best_score` 仍保存 | `menu.gd`、`PHASE-U-FULL-RUN.md` §2 |
| Z1 开场空跑 | **未修，下一轮第一件事**：0–30 s 无输入 / 5.91 s 起步段；Phase S、T、U 连续指向同一处 | `PHASE-S-DIFFICULTY-CURVE.md`、`PHASE-T-HUD-SCORE.md` §3.10、`PHASE-U-FULL-RUN.md` §7 |
| 自动驾驶种类 | **已修（Phase U）**：探针改读 `race.hazard_groups`；修复前 gate3/rock6/gate8 误触 | `stage3_playtest.gd` `_live_groups()`、`PHASE-U-FULL-RUN.md` §2 |

## 进程与任务锁

- 当前无 Godot 进程（Phase M 收尾时已清掉两个 12:53 启动的残留测试进程）。
- 锁文件：`docs/reports/longrun/.lock`，格式 `PID STARTED_AT`。
  2026-11-12 16:45 已删除陈旧锁（`7972 2026-11-12 02:10`，PID 已死）。
- 开始一轮工作前写入；正常结束/阶段结束删除；崩溃则保留，下一轮按“PID 是否仍存活”
  判活。提醒脚本不会启动第二个实例，也不会自动拉起 AI 会话。

## 最近一次完整回归

- Phase U（2026-11-12 19:11，`docs/reports/logs/phase-t/`）：
  窗口化 `stage3_playtest` 中英文各两圈（run1 Enter、run2 Retry），
  每圈 `passed=55/55`、`accidents=0`、`max_accident=0.00s`、`max_stuck=0.0s`、
  `grade=S`、三区全到；stdout 47 条 ok / 0 FAIL，**stderr 0 行**，0 条 SCRIPT ERROR。
  食物加速每圈 9 次真实触发（`SNACK eaten`，速度 253/276/299 = 基础 ×1.15），
  `LEVEL SEED 20261112` 可复现；自动驾驶改读 `race.hazard_groups` 后
  gate3/rock6/gate8 三个改种组零接触。
  headless 回归 15 项 exit=0、stderr 0 字节；窗口化 `stage4_menu_input`、
  `stage4_hud_contrast` PASS。`best.json` 跑前备份、跑后还原，
  md5 `1CAC4067611D1B059374F4E1379C4C24` 与备份一致。
  **以上都是自动驾驶/代理/窗口化自动输入，不是真人。**

- Phase M（2026-11-12 16:45，`docs/reports/logs/phase-m/`）：
  窗口化 `stage3_playtest` 两圈 `passed=55/55`、`accidents=0`、`grade=S`、
  `failures=0`、`STAGE3 PLAYTEST: PASS`，0 条 SCRIPT ERROR；
  headless 回归 16 个场景全部 exit=0、0 FAIL、stderr 0 字节；
  `best.json` 已从 `best.before-playtest.json` 还原并逐字节核对。
  全量解法矩阵重跑：dive 38→17、no_solution=[]、design_correct 55/55；
  容差扫描三片重跑，55/55 组通过区间与改动前逐组一致。
  **以上都是自动驾驶/代理，不是真人。**

- Phase J（2026-11-12 13:00，`docs/reports/logs/phase-j/`）：
  窗口化 `stage3_playtest` 两圈 `passed=55/55`、`accidents=0`、`score=9500`、
  `failures=0`、`STAGE3 PLAYTEST: PASS`，stdout/stderr 0 条 SCRIPT ERROR；
  回归 `reg-flow` / `reg-hud_priority` / `reg-bilingual` / `reg-bro_meter` 全 PASS
  （stderr 均 0 字节）。跑完已把 `best.json` 还原为
  `{"score_model":2,"best_time":296.63,"best_accidents":0,"best_score":-1,"best_streak":54}`，
  与备份 `logs/phase-j/best.before.json` 逐字节一致。**该日志是自动驾驶，不是真人。**

- Phase I（2026-11-12 04:0x，`docs/reports/logs/phase-i/`）：
  `reg-hud_layout` PASS（4.167% / 5.281%）、`reg-hud_priority` PASS
  （`HUD TIMING feedback=0.75 hint=2.19 prompt=3.00 max=3.00`）、
  `reg-bilingual` PASS、`reg-bro_meter` PASS、`reg-flow` PASS、
  `reg-menu-input` PASS（36 条 ok、12 次鼠标点击、DOWN/UP/SPACE/ENTER，窗口化）；
  `contrast.log` `STAGE4 HUD CONTRAST: PASS`（64 行，最差 4.76:1）。
  跑完核对 `best.json` 未变。

- `docs/reports/logs/phase-h/playtest-final.log`（2026-11-12 04:10，Phase H 最终几何）：
  两圈 `passed=55/55`、`accidents=0`、`score=9500`、`failures=0`、`max_stuck=0`、
  0 条 SCRIPT ERROR。该日志由 `stage3_playtest.tscn` 生成；跑完已把测试写的
  `best.json` 还原为
  `{"score_model":2,"best_time":296.63,"best_accidents":0,"best_score":-1,"best_streak":54}`
  （备份 `best.json.phaseh-final.bak`）。
- `docs/reports/logs/phase-h/final-*.log`：自动批 10 项 10/10 PASS，0 条 SCRIPT ERROR；
  `metrics-after-body.log`：`STAGE4 METRICS: PASS`。
- QC `tbb-stage4-penalty`：1–6 pass，7 pending → `NOT_VERIFIED`（缺真人）。
- QC `tbb-longrun-rescue`：1–5 pass，6 pending → `NOT_VERIFIED`。
- QC `tbb-stage4-combo-core`：1–10 pass，11 pending → `NOT_VERIFIED`。
- 自动批全部 PASS（…-phaseg.log）：stage4-penalty / bro meter / bilingual /
  stage2 / stage3 / flow / core experience / hud priority / shift graybox / proto；
  10 条日志均 0 条 SCRIPT ERROR。

## 时间预算与可行性（2026-11-12 02:07 评估）

- 制作人指定 07:00 提醒；此前口述执行窗口到 11:00。实际可执行窗口约 4 小时。
- 全量 M 节交付（救援循环 + 惩罚统一 + 三区重排 + HUD + 难度）不可能在 4 小时内
  以可验收质量完成；本任务按断点续跑推进，允许“部分完成 + 状态落盘”。
- 第一优先：C 审计 → F 救援原型（最大乐趣缺口）→ D/E 手感与连招窗口 →
  G 惩罚统一 → H/I 关卡与 HUD。每个子任务单独回归、单独更新本文件。
- 无法自动恢复 Claude 会话：提醒只能弹窗 + 打开 `RESUME_PROMPT.md`，
  不得声称已恢复。OS 级自动拉起会话属于未实现能力。

## 恢复点

- 基线（-01 开工）：`baseline-2026-11-12-0205.zip`
- **基线（-02 开工）：`baseline-2026-11-12-P02.zip`**（2026-11-12 16:54，
  scripts / scenes / project.godot / STAGE / STAGE-4 / 解法矩阵 / MISSION-02 / 本状态文件）
- 恢复提示：`RESUME_PROMPT.md`
- 提醒：`REMINDER.md` + `tools/longrun_reminder.ps1`

---

## 追加任务 TBB-LONGRUN-PLAYABILITY-02（2026-11-12 起）

- 原文：`MISSION-02.md`（制作人追加，不覆盖 `MISSION.md`）。
- 当前阶段仍是 `STAGE=4`；不进入 STAGE 5；真人试玩仍 `NOT TESTED`。
- 新玩法三件：TURTLE SNACK RUSH（可选进食 → 15% 短加速 → 加速后的随机障碍）、
  区域随机障碍池 + 固定种子、主动救援原型（Phase F 已有，需按新验收重验）。
- 另要求：解释并处理 0.154 s 窗口；HUD 增加加速状态/`TURBO!`；弱化固定总分；
  1280×720 的中英文字号问题；三区难度曲线按“组合判断而非手速”复审。

### 进度（-02）

| # | 步骤 | 状态 | 产物 / 证据 |
|---|---|---|---|
| 1 | 检查状态并建立新恢复点 | **DONE** 2026-11-12 16:54 | 本文件、`MISSION-02.md`、`baseline-2026-11-12-P02.zip` |
| 2 | 解释 0.154 s 窗口 | **DONE**（验收 6/7 已过，窗口化全程回归并入 #10） | `PHASE-N-0154.md`；`matrix-after.log` 55/55 有解、设计答案 55/55 |
| 3 | 食物加速单一原型 | **DONE** | `PHASE-O-SNACK.md`；`stage4_snack_rush` 3/3 PASS；`screenshots/stage4_snack_{before,gulp,turbo}.png` |
| 4 | 随机障碍候选池 + 种子复现 | **DONE**（QC 1–6 pass，7 = 真人 NOT TESTED） | `PHASE-P-DRAW.md`；`stage4_snack_draw` 23/23；默认种子 `20261112`，日志 `LEVEL SEED`；`solution-audit.log no_solution=[]` |
| 5 | 三区食物遭遇实测 | **DONE**（QC 6/6 pass） | `PHASE-P-ZONES.md`；`stage4_snack_zones` 默认种子 18/18、种子 424242 18/18；`zones.log` / `zones-seed424242.log`；`phase-p-zones*.json` |
| 6 | 修正不公平碰撞/预警 | **DONE** 2026-11-12 18:13（QC 7/7 pass） | `PHASE-Q-FAIRNESS.md`；只右移 Z3 的 9 组（+100…+420 px）；`warning-audit-after-q.log` MIN 4.017 s FAILS 0（改前 `--legacy` 3.833 s FAILS 1）；`solution-audit-after-q.log` 55/55；`metrics-after-q.log` 3.65/5.13 PASS；两种子 `zones-*-after-q.log` 18/18；`draw-after-q.log` 23/23。Z3 “复杂 ≥5 s” 与 1100 px 视野上限（4.231 s）冲突，已列为制作人决策项 |
| 7 | 主动救援原型 | **DONE** 2026-11-12 18:20（QC 7/7 pass） | `PHASE-R-RESCUE.md`；`stage4_rescue_boost` 25/25（`logs/phase-r/rescue-boost.log`）；加速中真实撞梁 → `RABBIT_WATER`；Z1 加速窗口 0.0–2.0 s、Z3（299 px/s）0.0–1.6 s；失败 3.22 s + 0.78 s 逐帧回壳（单帧 9.33 px）；事故只 +1 |
| 8 | 三区难度曲线 | **DONE** 2026-11-12 18:30（QC 8/8 pass） | `PHASE-S-DIFFICULTY-CURVE.md`；只读重算 `phase-s-curve.py` + `phase-s-difficulty-curve.json`；补测 5 px 细扫 rock8/rock4/shark3/shark1（`logs/phase-s/`）；密度 10.6/11.4/13.1 组每分；单动作窗口 Z3 不变窄（岩 0.432/0.458/0.462、鲨 0.386/0.458/0.500）；连招第一段 0.182/0.208/0.231（浮木）；Z1 8 s 空档已消除（最长 5.91 s 起点段）。Z3 连招占比与 Z2 持平（20.8% vs 21.1%），§五“组合判断”列为制作人决策项，未改关卡 |
| 9 | HUD / 评分表现 | **DONE** 2026-11-12 18:42（QC 11/11 pass） | `PHASE-T-HUD-SCORE.md`；`stage4_hud_score` 窗口化 44/44（`logs/phase-t/hud-score.log`）；HUD 与结算移除固定数字总分（`total_score`/`score_log` 保留）；结算七项含救援成功；`rescue_success_count` 接入 `_rescue_catch`；连招里程碑不再被“干净通过”覆盖；1280×720 最小实际字号 12→**14.4 px**；面板 4.52%/6.10%（≤8%）。回归 5 项全 PASS；`best.json` md5 前后一致 |
| 10 | 完整赛道回归 | **DONE** 2026-11-12 19:11 | `PHASE-U-FULL-RUN.md`；窗口化中英各两圈 55/55、0 事故、S、三区、`failures=0`；stdout 47 ok、stderr 0 行；`best.json` md5 前后 `1CAC…C24`。回归中修掉自动驾驶读原始种类（gate3/rock6/gate8 误触）、菜单残留最高分展示、菜单/暂停 11.2–12.8 px 字号，玩法未改 |
| 11 | 更新恢复点与验收入口 | **DONE** 2026-11-12 19:11 | 本文件 `NEXT`/本表、`RESUME_PROMPT.md` 改到 `-02`、新增 `PRODUCER-ACCEPTANCE.md`；`STAGE=4` 未动 |
