# RESUME — TBB-LONGRUN-PLAYABILITY-01 / -02

把这个文件的内容直接交给新的 Claude 会话即可续跑。

---

你在 `D:/GAMESTUDIO/TURBBIT` 继续执行 `TBB-LONGRUN-PLAYABILITY-01` 与追加的
`TBB-LONGRUN-PLAYABILITY-02`。

先做这四件事，不要跳过：

1. 读 `docs/reports/longrun/LONGRUN_STATE.md`、`MISSION.md`、`MISSION-02.md`。
2. 检查 `docs/reports/longrun/.lock`：
   - 若 PID 仍存活，说明另一轮还在跑，停止，不要并行修改。
   - 若 PID 已死，记录“stale lock”，删除后继续。
3. 检查 `git -C D:/GAMESTUDIO status --short -- TURBBIT`。注意 TURBBIT 未被 git 跟踪；
   回退只能取 `docs/reports/longrun/baseline-2026-11-12-P02.zip`（`-02` 开工基线）
   或更早的 `baseline-2026-11-12-0205.zip`。
4. 从状态文件的 `NEXT:` 一行继续；每完成一个子任务立即更新
   `LONGRUN_STATE.md`（`STATUS:` / `LAST_UPDATED:` / `NEXT:` 三行保持可解析）。

硬约束：

- 保持 `STAGE=4`，禁止进入 STAGE 5；本轮不宣布最终完成。
- 不跑 `LESSONS/CHECKS/preflight.py`。
- 素材冻结：不加图片/字体/音效/音乐；反馈用现有占位或原生 Control。
- 真人试玩一律 `NOT TESTED`；自动化、自动驾驶、代理驾驶、窗口化自动输入分开标注。
- 任何会冲线的测试前备份 `best.json`，测试后校验并还原；不得把测试成绩写成玩家纪录。
- 一次只改一个系统；改完窗口化实跑 + 相关回归 + 记录前后差异。
- 连续失败就回退到基线/稳定版，记录失败原因，不硬推。
- 本机 OS 级键盘注入被系统拒绝（`SendInput` 返回 0），只能用引擎内输入代理；
  不得写成“真人试玩”或“窗口化真实按键”。

## 当前状态（2026-11-12 19:11）

`-02` 的 §七 11 步全部完成：
- 1 恢复点、2 0.154 s 解释、3 食物加速、4 随机池与种子、5 三区遭遇、
  6 公平碰撞/预警、7 主动救援、8 难度曲线、9 HUD/评分、
  10 完整赛道回归、11 状态与验收入口。
- 报告依次见 `PHASE-N-0154.md`、`PHASE-O-SNACK.md`、`PHASE-P-DRAW.md`、
  `PHASE-P-ZONES.md`、`PHASE-Q-FAIRNESS.md`、`PHASE-R-RESCUE.md`、
  `PHASE-S-DIFFICULTY-CURVE.md`、`PHASE-T-HUD-SCORE.md`、`PHASE-U-FULL-RUN.md`。
- 最新完整回归：中英文各两圈 55/55、0 事故、S、三区、`failures=0`，
  stdout 47 ok / stderr 0 行；`best.json` md5 `1CAC4067611D1B059374F4E1379C4C24`。
- 制作人验收入口：`PRODUCER-ACCEPTANCE.md`。

## 下一轮第一件事

**改 Z1 开场 0–30 s 空跑**：前 5.91 s 无输入，第一个连招约 t=49.6 s。
Phase S、T、U 连续三次指到同一处；按 `TURBBIT/CLAUDE.md`，必须先改再继续。
改之前先写 QC 验收标准（可判定句子 + 一条有趣性判断），改完窗口化实跑并回归。

## 仍未验证

- 真人试玩：`NOT TESTED`（所有手感、难度、有趣性结论都缺真人数据）。
- Z3 复杂障碍 5 s 预警：受 1100 px 视野上限限制，实测 4.231 s，待制作人决策。
- Z3 连招占比 20.8% 是否达到“组合判断”目标，待制作人判断。
