extends Control
## 阶段 4 重设计 HUD：紧凑、内容自适应，不再有四块大面积空面板。
## 左上：SHIFT 当前控制 + 两个角色各自的“操控 / 待命·稳定”，
##       只有真的失衡时才出现一条“兔子失衡 18% / 乌龟倾覆风险 40%”。
## 右上：时间（mm:ss.t）、区域、进度。没有速度行。
## 左下：氧气 + 状态 + 分格条。右下：默契 0/3 三格。
## 底部中央：首次遇到某类障碍时教一次；干净通过/BRO PASS 短反馈。
## 数据全部来自 race 与 GameManager，不自己存副本。

const Tuning = preload("res://scripts/systems/tuning.gd")

const PANEL_BG := Color(0.02, 0.07, 0.1, 0.6)
const PANEL_BORDER := Color(0.4, 0.8, 0.95, 0.28)
const TEXT := Color(0.92, 0.97, 1.0)
const MUTED := Color(0.62, 0.76, 0.86)
const GOLD := Color(1.0, 0.86, 0.35)
const GREEN := Color(0.45, 0.95, 0.6)
const AMBER := Color(1.0, 0.8, 0.3)
const RED := Color(1.0, 0.36, 0.3)
const CYAN := Color(0.45, 0.95, 1.0)

var race: Node = null

var _panels := {}
var _bottom_center: VBoxContainer

var control_label: Label
var rabbit_role: Label
var rabbit_status: Label
var turtle_role: Label
var turtle_status: Label
var rabbit_risk_row: HBoxContainer
var rabbit_risk_label: Label
var rabbit_risk_bar: ProgressBar
var turtle_risk_row: HBoxContainer
var turtle_risk_label: Label
var turtle_risk_bar: ProgressBar

var time_label: Label
var zone_label: Label
var progress_label: Label

var oxygen_label: Label
var oxygen_status: Label
var oxygen_segs: Array[ColorRect] = []

var score_label: Label
var bro_meter_label: Label
var bro_meter_segs: Array[ColorRect] = []
var bond_label: Label
var bond_segs: Array[ColorRect] = []

var feedback_label: Label
var hint_label: Label
var prompt_label: Label

var hint_text := ""
var hint_timer := 0.0
var feedback_text := ""
var feedback_kind := "clean"
var feedback_timer := 0.0
var prompt_text := ""
var prompt_timer := 0.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	var tl := _make_panel("tl")
	control_label = _label(tl, 17, GOLD)
	var rabbit_row := HBoxContainer.new()
	rabbit_row.add_theme_constant_override("separation", 10)
	tl.add_child(rabbit_row)
	rabbit_role = _label(rabbit_row, 16, TEXT)
	rabbit_status = _label(rabbit_row, 16, GREEN)
	var turtle_row := HBoxContainer.new()
	turtle_row.add_theme_constant_override("separation", 10)
	tl.add_child(turtle_row)
	turtle_role = _label(turtle_row, 16, TEXT)
	turtle_status = _label(turtle_row, 16, GREEN)
	var rr := _risk_row(tl, CYAN)
	rabbit_risk_row = rr[0]
	rabbit_risk_label = rr[1]
	rabbit_risk_bar = rr[2]
	var trt := _risk_row(tl, AMBER)
	turtle_risk_row = trt[0]
	turtle_risk_label = trt[1]
	turtle_risk_bar = trt[2]

	var tr := _make_panel("tr")
	time_label = _label(tr, 25, TEXT)
	time_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	zone_label = _label(tr, 15, MUTED)
	zone_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	progress_label = _label(tr, 15, MUTED)
	progress_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	# 阶段 4：当前分数就在结算会显示的那一行上，玩家一路都看得到。
	score_label = _label(tr, 18, GOLD)
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	var bl := _make_panel("bl")
	oxygen_label = _label(bl, 18, TEXT)
	oxygen_status = _label(bl, 13, GREEN)
	var oxy_row := HBoxContainer.new()
	oxy_row.add_theme_constant_override("separation", 4)
	bl.add_child(oxy_row)
	for i in 4:
		var seg := ColorRect.new()
		seg.custom_minimum_size = Vector2(26, 8)
		seg.color = Color(0.2, 0.28, 0.32, 0.8)
		oxy_row.add_child(seg)
		oxygen_segs.append(seg)

	var br := _make_panel("br")
	# BRO METER 在默契上方：三格是“失误槽”，填满触发联合惩罚；
	# 默契是“连招槽”，满了进 SHOWTIME。两者含义不同，不能合并。
	bro_meter_label = _label(br, 16, RED)
	bro_meter_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	var bro_row := HBoxContainer.new()
	bro_row.alignment = BoxContainer.ALIGNMENT_END
	bro_row.add_theme_constant_override("separation", 6)
	br.add_child(bro_row)
	for i in GameManager.BRO_METER_SLOTS:
		var seg := ColorRect.new()
		seg.custom_minimum_size = Vector2(30, 8)
		seg.color = Color(0.18, 0.12, 0.12, 0.85)
		bro_row.add_child(seg)
		bro_meter_segs.append(seg)
	bond_label = _label(br, 18, GOLD)
	bond_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	var bond_row := HBoxContainer.new()
	bond_row.alignment = BoxContainer.ALIGNMENT_END
	bond_row.add_theme_constant_override("separation", 6)
	br.add_child(bond_row)
	for i in Tuning.SHOWTIME_COMBO:
		var seg := ColorRect.new()
		seg.custom_minimum_size = Vector2(30, 10)
		seg.color = Color(0.26, 0.24, 0.18, 0.85)
		bond_row.add_child(seg)
		bond_segs.append(seg)

	# 底部中央不挂面板：文字直接压在画面上，避免挡角色和障碍。
	_bottom_center = VBoxContainer.new()
	_bottom_center.alignment = BoxContainer.ALIGNMENT_END
	_bottom_center.add_theme_constant_override("separation", 4)
	add_child(_bottom_center)
	feedback_label = _label(_bottom_center, 26, GOLD)
	feedback_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label = _label(_bottom_center, 15, MUTED)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt_label = _label(_bottom_center, 22, CYAN)
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	feedback_label.visible = false
	hint_label.visible = false
	prompt_label.visible = false

	GameManager.hint.connect(_on_hint)
	GameManager.feedback.connect(_on_feedback)
	GameManager.prompt.connect(_on_prompt)
	Locale.language_changed.connect(_on_language_changed)


func _process(delta: float) -> void:
	if hint_timer > 0.0:
		hint_timer = maxf(hint_timer - delta, 0.0)
	if feedback_timer > 0.0:
		feedback_timer = maxf(feedback_timer - delta, 0.0)
	if prompt_timer > 0.0:
		prompt_timer = maxf(prompt_timer - delta, 0.0)
	if race == null or not is_instance_valid(race):
		return
	if race.turtle == null or race.rabbit == null:
		return
	_refresh()
	_layout()


func _refresh() -> void:
	# ---- 左上：控制权 + 双方状态 ----
	var cur: String = GameManager.current_control
	control_label.text = Locale.t("hud.control_now", [Locale.t("who." + cur)])
	rabbit_role.text = Locale.t("who.rabbit")
	turtle_role.text = Locale.t("who.turtle")
	var rabbit_risk: int = race.rabbit_imbalance_pct()
	var turtle_risk: int = race.turtle_imbalance_pct()
	if cur == "rabbit":
		rabbit_status.text = Locale.t("hud.acting", [_rabbit_action()])
		rabbit_status.add_theme_color_override("font_color", GOLD)
		turtle_status.text = Locale.t("hud.standby_stable") \
			if turtle_risk <= 0 else Locale.t("hud.standby_risk")
		turtle_status.add_theme_color_override("font_color",
			GREEN if turtle_risk <= 0 else AMBER)
	else:
		turtle_status.text = Locale.t("hud.acting", [_turtle_action()])
		turtle_status.add_theme_color_override("font_color", GOLD)
		rabbit_status.text = Locale.t("hud.standby_stable") \
			if rabbit_risk <= 0 else Locale.t("hud.standby_risk")
		rabbit_status.add_theme_color_override("font_color",
			GREEN if rabbit_risk <= 0 else AMBER)

	# 失衡只在真的有风险时出现，百分比和条同时出现，不做两条永久空条。
	rabbit_risk_row.visible = rabbit_risk > 0
	rabbit_risk_label.text = Locale.t("hud.rabbit_risk", [rabbit_risk])
	rabbit_risk_label.add_theme_color_override("font_color", _risk_color(rabbit_risk))
	rabbit_risk_bar.value = rabbit_risk
	_set_bar_color(rabbit_risk_bar, _risk_color(rabbit_risk))
	turtle_risk_row.visible = turtle_risk > 0
	turtle_risk_label.text = Locale.t("hud.turtle_risk", [turtle_risk])
	turtle_risk_label.add_theme_color_override("font_color", _risk_color(turtle_risk))
	turtle_risk_bar.value = turtle_risk
	_set_bar_color(turtle_risk_bar, _risk_color(turtle_risk))

	# ---- 右上：时间 / 区域 / 进度 ----
	var t: float = GameManager.race_time
	time_label.text = "%02d:%04.1f" % [int(t / 60.0), fmod(t, 60.0)]
	zone_label.text = Locale.t("hud.zone",
		[race.zone_id(), Locale.zone_name(race.zone_id())])
	progress_label.text = Locale.t("hud.progress", [
		int(round(race.progress() * 100.0)), race.passed_count(), race.total_groups()])
	score_label.text = Locale.t("hud.score", [GameManager.total_score])

	# ---- 左下：氧气 ----
	var ox: float = GameManager.oxygen
	oxygen_label.text = Locale.t("hud.oxygen", ["%.1f" % ox])
	var status := ""
	var status_color := GREEN
	if GameManager.accident_state == "OXYGEN_OUT":
		status = Locale.t("hud.emergency")
		status_color = RED
	elif race.mount.state != "RIDING":
		status = Locale.t("hud.airborne")
		status_color = CYAN
	elif race.turtle.dunk_timer > 0.0 \
			or race.turtle.position.y > race.surface_y() + Tuning.OXYGEN_DEPTH_MARGIN:
		status = Locale.t("hud.underwater")
		status_color = RED
	elif GameManager.oxygen_phase == "CRITICAL":
		status = Locale.t("hud.oxygen_critical")
		status_color = RED
	elif GameManager.oxygen_phase == "LOW":
		status = Locale.t("hud.oxygen_low")
		status_color = AMBER
	else:
		status = Locale.t("hud.oxygen_recovering")
		status_color = GREEN
	oxygen_status.text = status
	oxygen_status.add_theme_color_override("font_color", status_color)
	var filled := int(ceil(ox / Tuning.OXYGEN_MAX * 4.0))
	if ox <= 0.01:
		filled = 0
	for i in oxygen_segs.size():
		var on := i < filled
		if not on:
			oxygen_segs[i].color = Color(0.2, 0.28, 0.32, 0.8)
		elif filled == 1:
			oxygen_segs[i].color = RED
		elif filled == 2:
			oxygen_segs[i].color = AMBER
		else:
			oxygen_segs[i].color = Color(0.35, 0.95, 0.7)

	# ---- 右下：BRO METER（失误槽）+ 默契（连招槽） ----
	bro_meter_label.text = Locale.t("hud.bro_meter",
		[GameManager.bro_meter, GameManager.BRO_METER_SLOTS])
	for i in bro_meter_segs.size():
		var used: bool = i < GameManager.bro_meter
		if used and GameManager.bro_meter >= GameManager.BRO_METER_SLOTS:
			bro_meter_segs[i].color = Color(1.0, 0.15, 0.1)
		elif used:
			bro_meter_segs[i].color = RED
		else:
			bro_meter_segs[i].color = Color(0.18, 0.12, 0.12, 0.85)
	if race.showtime_active:
		bond_label.text = Locale.t("hud.showtime_t", ["%.1f" % race.showtime_left()])
		bond_label.add_theme_color_override("font_color", AMBER)
	else:
		bond_label.text = Locale.t("hud.bond", [race.combo, Tuning.SHOWTIME_COMBO])
		bond_label.add_theme_color_override("font_color", GOLD)
	for i in bond_segs.size():
		var lit: bool = i < race.combo
		if race.showtime_active:
			lit = true
		bond_segs[i].color = GOLD if lit else Color(0.26, 0.24, 0.18, 0.85)

	# ---- 底部中央：反馈 / 一次性教学 / 提示 ----
	feedback_label.visible = feedback_timer > 0.0
	feedback_label.text = feedback_text
	feedback_label.add_theme_color_override("font_color", _feedback_color(feedback_kind))
	hint_label.visible = hint_timer > 0.0
	hint_label.text = hint_text
	prompt_label.visible = prompt_timer > 0.0
	prompt_label.text = prompt_text
	var a := 1.0
	if prompt_timer > 0.0 and prompt_timer < 0.6:
		a = prompt_timer / 0.6
	prompt_label.modulate.a = a


func _rabbit_action() -> String:
	if race.showtime_active:
		return Locale.state_name("SHOWTIME")
	if race.mount.state == "AIRBORNE":
		return Locale.state_name("AIRBORNE")
	if race.rabbit_stun > 0.0:
		return Locale.state_name("STUNNED")
	if race.turtle.leap_active:
		return Locale.state_name("LEAPING")
	if race.rabbit.daze_time > 0.01:
		return Locale.state_name("RECOVERING")
	return Locale.state_name(race.rabbit.state)


func _turtle_action() -> String:
	if race.turtle.accident:
		return Locale.state_name("UNCONSCIOUS")
	if race.turtle.leap_active:
		return Locale.state_name("LEAPING")
	if race.turtle.diving:
		return Locale.state_name("DIVING")
	if race.turtle.dunk_timer > 0.0:
		return Locale.state_name("DUNKED")
	if race.turtle.daze_time > 0.01:
		return Locale.state_name("RECOVERING")
	if race.turtle.speed > race.turtle.base_speed + 10.0:
		return Locale.state_name("BOOSTING")
	return Locale.state_name("CRUISING")


func _risk_color(pct: int) -> Color:
	if pct >= 80:
		return RED
	if pct >= 50:
		return Color(1.0, 0.55, 0.25)
	if pct >= 25:
		return AMBER
	return Color(0.55, 0.8, 1.0)


func _feedback_color(kind: String) -> Color:
	match kind:
		"bro", "pop":
			return GOLD
		"hit":
			return RED
		_:
			return CYAN


func _layout() -> void:
	var vp := get_viewport_rect().size
	for corner in _panels:
		var panel: PanelContainer = _panels[corner]
		if not panel.visible:
			continue
		var ms := panel.get_combined_minimum_size()
		panel.size = ms
		match corner:
			"tl":
				panel.position = Vector2(14, 14)
			"tr":
				panel.position = Vector2(vp.x - 14.0 - ms.x, 14)
			"bl":
				panel.position = Vector2(14, vp.y - 14.0 - ms.y)
			"br":
				panel.position = Vector2(vp.x - 14.0 - ms.x, vp.y - 14.0 - ms.y)
	var bc_size := _bottom_center.get_combined_minimum_size()
	_bottom_center.size = bc_size
	_bottom_center.position = Vector2((vp.x - bc_size.x) * 0.5,
		vp.y - 16.0 - bc_size.y)


func _on_hint(text: String) -> void:
	hint_text = text
	hint_timer = 2.2


func _on_feedback(text: String, kind: String) -> void:
	feedback_text = text
	feedback_kind = kind
	feedback_timer = 0.75


func _on_prompt(text: String) -> void:
	prompt_text = text
	prompt_timer = 3.0


func _on_language_changed(_code: String) -> void:
	# 旧语言的文字不能残留到新语言里。
	hint_timer = 0.0
	feedback_timer = 0.0
	prompt_timer = 0.0
	hint_text = ""
	feedback_text = ""
	prompt_text = ""


func _make_panel(corner: String) -> VBoxContainer:
	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = PANEL_BG
	style.border_color = PANEL_BORDER
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	panel.add_theme_stylebox_override("panel", style)
	add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	panel.add_child(box)
	_panels[corner] = panel
	return box


## 返回 [行, 标签, 条]；GDScript 不能通过参数把新建节点传回调用方。
func _risk_row(parent: VBoxContainer, fill: Color) -> Array:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	parent.add_child(row)
	var label := _label(row, 14, fill)
	var bar := ProgressBar.new()
	bar.min_value = 0
	bar.max_value = 100
	bar.value = 0
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(96, 8)
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.add_theme_stylebox_override("background", _bar_style(Color(0.12, 0.16, 0.2, 0.9)))
	bar.add_theme_stylebox_override("fill", _bar_style(fill))
	row.add_child(bar)
	row.visible = false
	return [row, label, bar]


func _bar_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(4)
	return style


func _set_bar_color(bar: ProgressBar, color: Color) -> void:
	bar.add_theme_stylebox_override("fill", _bar_style(color))


func _label(parent: Container, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	label.add_theme_constant_override("shadow_offset_x", 2)
	label.add_theme_constant_override("shadow_offset_y", 2)
	parent.add_child(label)
	return label
