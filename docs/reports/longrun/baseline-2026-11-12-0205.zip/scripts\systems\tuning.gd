class_name Tuning
extends RefCounted
## 全项目数值集中在这里，改难度只改这个文件。
## 出处：GDD 05.6 物理宽限、05.5 氧气、08 事故、09 Showtime。
##
## 2026-11-11 核心体验指令：失控从 3.6 s 放宽到约 9.5 s，并拆成五段：
##   0～1.5    稳定期：只是松弛/掉动力，位置不动
##   1.5～4.5  轻微：兔子开始滑、乌龟慢慢往下漂
##   4.5～7.5  明显：滑出小半、下沉看得出，状态变黄
##   7.5～9.5  临界：快掉了/太深了，红字预警
##   ≥9.5      事故；乌龟还会在 y≥740 提前翻肚皮
## 切换自由、失衡真实：夺回控制不清零，0.5 s 站稳后按 2.5/s 慢慢收。
const RELAX_TIME := 1.5
const SLIP_EDGE_TIME := 4.5
const SLIP_CRITICAL_TIME := 7.5
const SLIP_FALL_TIME := 9.5
const SINK_EDGE_TIME := 4.5
const SINK_CRITICAL_TIME := 7.5
const SINK_DANGER_TIME := 9.5

# 加速时失控时钟走得更快：同样的窗口会缩到约 3/4。
const SLIP_BOOST_CLOCK := 1.35
const SLIDE_PIXELS := 70.0
const BOOST_SPEED := 330.0

## 重新夺回控制权后的恢复速度：滑落/下沉计时按时间衰减，不瞬间清零。
## GDD 6.3「不允许通过切换直接重置滑落进度」。
## 连续控制满 0.5 s 才开始恢复：防止快速连点 SHIFT 把两人的风险一起磨掉；
## 恢复到稳的速率 2.5/s，从 EDGE 约需 1.8 s（含 0.5 s 站稳）。
const CONTROL_RECOVER_DELAY := 0.5
const CONTROL_RECOVER_RATE := 2.5

# 氧气：GDD 建议 5 秒；按反馈延长到 8 秒，三档 5 / 2.5 / 0。
const OXYGEN_MAX := 8.0
const OXYGEN_LOW := 5.0
const OXYGEN_CRITICAL := 2.5
const OXYGEN_DRAIN := 1.0
const OXYGEN_RECOVER := 3.0
const OXYGEN_RECOVERED := 5.0

# 接人：横向 120 px，落点上下 -60～90，近距离直接吸附。
const PICKUP_DX := 120.0
const PICKUP_DY_MIN := -60.0
## 接住“正在上浮”的壳时放宽：BRO DIVE 里兔子要落在还没完全浮起的壳上。
## 巡航中的壳仍用 -60，否则兔子会在半空被提前吸上壳（越过低岩时会被拽进岩里）。
const PICKUP_DY_MIN_RISING := -120.0
const PICKUP_DY_MAX := 90.0
const PICKUP_SNAP_DX := 70.0

# ---- 非对称冲浪板（2026-11-11 制作人定稿方向）----
# 兔子站在龟壳上；乌龟不再接受玩家的上/下控深，受控时用自动浮力回到
# NEUTRAL_DEPTH，失控时才下沉，重新受控再自动上浮。保留惯性，不瞬移。
# 灰盒会临时置 false 做“改前”对照；正式流程为 true（2026-11-11 接入）。
static var SURFBOARD_PHYSICS := true

const NEUTRAL_DEPTH := 334.0
## 障碍/加速带数据仍按旧水面 300 摆放；开启后整体下移同样的量，
## 保持“角色与障碍”的相对几何和旧验证完全一致。
const WORLD_Y_SHIFT := NEUTRAL_DEPTH - 300.0

## 自动浮力：离巡航水深越远垂直速度越大，但有上下限和加速度，
## 所以是“漂回去”而不是瞬移。150 px/s 只用于紧急上浮量级。
const BUOY_RISE_SPEED := 150.0
const BUOY_SINK_SPEED := 90.0
const BUOY_ACCEL := 240.0
const BUOY_GAIN := 3.0

## 失控下沉：一失去意识就开始沉，但整体放慢到“看得见、来得及”。
## 35 → 40 → 55 → 80 px/s 四段：下沉门（墙底 334）要求壳沉 31 px 才让开，
## 第一段 25 px/s 时在 220 px/s 的巡航速度下要提前 1.2 s 换人才过得去，
## 实测全跑两场各有 2 个门在“墙前 300 px 换人”时差 8 px 撞墙；
## 提到 35 后同样提前量能沉到 365，门内仍只有 40/55 px/s，不会变成快沉。
## 惰性神游仍要 8.3 s 才碰危险深度 740，不会变成 3 秒倒计时。
const SINK_RELAX := 35.0
const SINK_SLOW := 40.0
const SINK_FAST := 55.0
const SINK_CRITICAL := 80.0
const SINK_RAMP := 90.0
## 兔子握权时乌龟失控：速度按段掉到 140 → 110 → 90 → 70，门里仍有 ~100 px/s。
const DAZE_SPEED_1 := 140.0
const DAZE_SPEED_2 := 110.0
const DAZE_SPEED_3 := 90.0
const DAZE_SPEED_4 := 70.0
## 水下暗流：兔子握着控制权、壳已经沉到巡航水深以下 76 px（y>410）时，
## 兔子层障碍的“水下部分”仍会把兔子撞下来（防止靠一直下沉绕过跳/趴）。
## 410 是兔子站着从岩石/横梁底下“擦过去”的临界深度；再深就是免费绕行。
## 画面上用一层半透明暗流柱标出来，不是隐形判定。
## 解除办法：把控制权交回乌龟，浮力会把壳抬回巡航水深。
const UNDERTOW_MARGIN := 76.0

## 接人：巡航水深 + 120 px 内都算够得着（新模型没有手动上浮，容错要宽）。
## 实测：兔子滞空 1.244 s，期间壳无人控制会沉 70～105 px；原来 70 px 的
## 余量正好卡在“跳一次就接不回来”，落地即落水的假难度就是这么来的。
const PICKUP_SURFACE_MARGIN := 120.0
## 氧气：以巡航水深为基准，再往下 80 px 才消耗。
## 新模型里兔子握着控制权时壳会自己沉，正常节拍下会沉到 400～430；
## 更低梁要趴 2 s，出口能到 550 上下。55 px 的余量让“过梁”本身就在抽氧，
## 自动驾驶实测在 49 s / 70 s 两次因过梁后的深位把氧气耗尽。
## 80 px（消耗线 414）之后才真的是“压得太深”。
const OXYGEN_DEPTH_MARGIN := 80.0

# ---- 2026-11-11 核心玩法重设计：待命不再恶化，失衡只来自错误 ----
# 兔子/乌龟的失衡值改用“秒”计：不再随待命时间增长，只在碰撞、错误着陆、
# 特殊动作失败时按事件加值；受控稳定操控（0.5 s 站稳后）按 2.5/s 收回。
## 一次碰撞加多少失衡。乌龟一次撞击 4.4；兔子 3.2，三次到落水。
const RABBIT_HIT_IMBALANCE := 3.2
const TURTLE_HIT_IMBALANCE := 4.4
## 乌龟主动垂直动作（2026-11-11 补充指令）：
## ↑ 带动整组向上跃起躲水下攻击；↓ 主动下潜过水下通道。
## 两者都不是事故、不加失衡；松开/通过后自动回巡航水深。
## 跃起：一次性上抛，1.6 s，落回巡航水深。
## 时长按“乌龟整个身体（96 宽）都要高过鲨鱼”反推：220 px/s 下
## 需要约 1.2 s 高于鲨鱼顶，1.0 s 的跃起只剩 0.2 s 容错，等于帧级输入。
## 峰值 2026-11-12 由 250 降到 160：BRO OLLIE 的高墙楣要能压住“骑在壳上”
## 的兔子（壳上 58、半身 24）。250 峰值时兔子已到 y=2，任何墙楣都压不到它，
## 兔子也就没有需要玩家补那一下的空间。160 时跃起到顶：龟心 174、壳 146～202、
## 兔身 92～140 —— 墙楣 80～120 只压兔子、窗口 120～230 只放壳。
## 鲨鱼复核：壳底 362-160=202 < 鲨鱼顶 240，仍能过；容错窗口约 0.76 s。
const LEAP_TIME := 1.6
const LEAP_HEIGHT := 160.0
const LEAP_COOLDOWN := 0.40
## BRO OLLIE 的兔子蹬踏：独立于普通跳（-630 -> 184 px）的一次较短的弹跳。
## 蹬踏点兔心在 163 左右，+119 px 后身体 20～68，刚好高过墙楣顶 80；
## 落回仍走 can_pickup（下坠 + 纵向窗口），不额外造“自动接人”。
const OLLIE_KICK_VELOCITY := -500.0
## 下潜：按住 ↓ 下到巡航水深以下 150 px；通过障碍后自动上浮。
## 深度要同时满足两条几何：龟壳顶让开水下障碍底（>28 px），
## 且壳上的兔子头顶也要让开（兔心在壳上 58、半身高 24 → 需要 >110 px）。
## 上浮 420 / 加速 1400 是“破水而出”的推力：障碍尾端到兔子落回之间
## 只有约 0.5 s，慢了就会“壳还在深处、兔子已经落地”。
const DIVE_DEPTH := 150.0
## 下沉 600 / 加速 6000：BRO DIVE 要在壳前沿进浮木前把壳顶从 306 沉到 410 以下，
## 旧的 480/2400 有 0.2 s 加速段、全程 0.32 s，加上换人延迟后起跳窗口只剩 ~6 px。
## 600/6000 把这一段压到 0.22 s（0.1 s 到满速），窗口回到 ~35 px。深度不变，
## 所以鲨鱼（身体到 480）仍能压住最深的下潜，下潜依然不是万能解。
const DIVE_SINK_SPEED := 600.0
const DIVE_RISE_SPEED := 420.0
const DIVE_ACCEL := 6000.0
## 被水下攻击/墙拍中后整组短暂没入水下，氧气因此真正有意义。
const DUNK_TIME := 1.8
const DUNK_DEPTH := 115.0
## 首次介绍提示的触发距离：组合障碍要求提前约 5 s 识别（220 px/s × 5 s = 1100）。
const PROMPT_RANGE := 1100.0
## Showtime 不再瞬间回满氧气，只小幅回复。
const SHOWTIME_OXYGEN := 1.5

const STUN_TIME := 0.8
## 事故演出：短、夸张、马上回到玩法。修复/救援 1.6 s，配 0.15 s 闪白。
const RESCUE_TIME := 1.6
const REPAIR_TIME := 1.6
const ACCIDENT_FLASH := 0.15
const EMERGENCY_TIME := 2.0
## 事故后的同源保护：核心体验指令要求 3 s 内不出现同源连续事故。
## 2.5 只比 1.6 s 的救援多 0.9 s，兔子刚站回壳上就还在梁下，会立刻二连摔。
const HAZARD_COOLDOWN := 3.0
## 触礁修复后乌龟仍停在障碍里；冷却要覆盖 2 s 修复 + 约 2 s 反应/下潜。
const TURTLE_COOLDOWN := 4.0
const GRACE_TIME := 2.0
const SHOWTIME_TIME := 1.8
const SHOWTIME_COMBO := 3
