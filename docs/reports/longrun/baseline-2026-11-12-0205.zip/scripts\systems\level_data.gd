class_name LevelData
extends RefCounted
## 阶段 3 赛道数据：三个区域、障碍组、加速段、教学提示。
## 所有坐标以世界像素为单位；SURFACE_Y=300，危险深度=740。
## 阶段 2 的前 8 组位置保持不变，保证旧自检/回归仍然有效。

const SURFACE_Y := 300.0
const WORLD_END := 67600.0
const COMBO_GAP := 1200.0
const PAR_TIME := 300.0

const ZONES := [
	{
		"id": 1, "name": "SUNNY COAST", "start": 0.0, "end": 15000.0,
		"base_speed": 220.0, "grade_color": Color(0.45, 0.95, 1.0),
		"sky": Color(0.55, 0.80, 0.92), "water": Color(0.06, 0.42, 0.55),
		"deep": Color(0.03, 0.28, 0.40), "seabed": Color(0.75, 0.68, 0.45),
		"lesson": "ZONE 1  SUNNY COAST - LEARN THE WATER",
	},
	{
		"id": 2, "name": "CORAL CHAOS", "start": 15000.0, "end": 39000.0,
		"base_speed": 240.0, "grade_color": Color(1.0, 0.55, 0.65),
		"sky": Color(0.46, 0.73, 0.88), "water": Color(0.10, 0.43, 0.52),
		"deep": Color(0.05, 0.23, 0.36), "seabed": Color(0.62, 0.48, 0.42),
		"lesson": "ZONE 2  CORAL CHAOS - CHAIN YOUR SWITCHES",
	},
	{
		"id": 3, "name": "MUSCLE MAYHEM", "start": 39000.0, "end": WORLD_END,
		"base_speed": 260.0, "grade_color": Color(1.0, 0.80, 0.35),
		"sky": Color(0.93, 0.58, 0.38), "water": Color(0.16, 0.36, 0.50),
		"deep": Color(0.08, 0.18, 0.32), "seabed": Color(0.52, 0.40, 0.32),
		"lesson": "ZONE 3  MUSCLE MAYHEM - NO MORE WARM-UPS",
	},
]

# ---- 2026-11-11 障碍空间重映射 ----
# 不再按旧名词分“岩石 / 低梁 / 浪墙”，按“占哪一层空间、谁来处理”分五类：
#   LOW_BIRD / LOW_BEAM  A 兔子层·趴低：只压站立兔（252～300），龟壳巡航高度（306～362）不动
#   SURFACE_ROCK         A 兔子层·跳跃：只压兔子；岩檐 296 让开龟壳顶 306 十像素
#   SHARK                C 水下攻击：整条身体从海底冲到水面（274～480）。下潜最深时壳顶 456
#                        仍在 480 以上，所以躲不开；必须乌龟跃起 160 px 把整组带高。
#   DIVE_GATE            D 水下通道：压巡航龟壳；乌龟下潜 150 px 后兔头顶 402 让开下沿 384
#   FLOATING_LOG         B 组合：上沿 192 压跃起后的壳底 202（只跃起也过不去）、下沿 410
#                        压巡航龟壳与深潜兔；兔子跳上沿、乌龟潜下沿，两条路都要走
#                        上沿从 180 抬到 192、宽度 50→32：跳跃变矮后“兔子在空中
#                        且高于上沿”的窗口只有 0.21~0.99 s，而下潜从起步到壳顶低于
#                        410 需要 ~0.22 s（DIVE_ACCEL 有加速段）。180+50 宽时两者
#                        只剩 9 px 起跳窗口，抬 12 px、收窄 18 px 后回到 ~35 px。
# 每组只记 x 与宽度；y 与高度来自类型模板，判定框和画法出自同一份数据。
const KIND_SPEC := {
	"LOW_BIRD": {"y": 200.0, "h": 40.0, "w": 120.0,
		"hint": "LOW BIRD", "action": "CROUCH DOWN",
		"lesson": "LOW BIRD - THE RABBIT CROUCHES"},
	"LOW_BEAM": {"y": 140.0, "h": 100.0, "w": 170.0,
		"hint": "DOCK BEAM", "action": "CROUCH DOWN",
		"lesson": "DOCK BEAM - CROUCH, THE SHELL KEEPS CRUISING"},
	"SURFACE_ROCK": {"y": 220.0, "h": 42.0, "w": 120.0,
		"hint": "LOW ROCK", "action": "JUMP OVER",
		"lesson": "JUMP THE ROCK - THE TURTLE PASSES UNDER"},
	"SHARK": {"y": 240.0, "h": 206.0, "w": 70.0,
		"hint": "SHARK", "action": "TURTLE LEAP",
		"lesson": "SHARK - TAKE THE TURTLE AND PRESS UP"},
	"DIVE_GATE": {"y": 170.0, "h": 180.0, "w": 180.0,
		"hint": "REEF ARCH", "action": "TURTLE DIVE",
		"lesson": "REEF ARCH - TAKE THE TURTLE AND HOLD DOWN"},
	"FLOATING_LOG": {"y": 158.0, "h": 218.0, "w": 32.0,
		"hint": "FLOATING LOG", "action": "JUMP + DIVE",
		"lesson": "FLOATING LOG - JUMP, SWITCH, DIVE"},
	# 高墙是两段矩形：墙楣（压骑乘兔）+ 墙身（压巡航壳和深潜路线），
	# 中间 120～230 的窗口只放得下跃起到顶的壳。y/h 这里给整墙的外部尺寸，
	# 真正的两段几何由组的 rects 明确写死（build_group 的单矩形不适用）。
	"HIGH_WALL": {"y": 86.0, "h": 400.0, "w": 30.0,
		"hint": "HIGH WALL", "action": "LEAP + KICK",
		"lesson": "HIGH WALL - LEAP, SWITCH, KICK"},
}

# 55 组。节奏按“一次只教一个东西 → 开始连换 → 收紧”排：
#   Z1 教学：趴低 → 跳跃 → 跃起 → 下潜 → 组合，每类先单独出现再重复；
#   Z2 连换：兔子 / 乌龟交替，组合每 3～4 组一次；
#   Z3 收紧：组合 4 次，单角色间距 1000 px（260 px/s = 3.85 s）。
# 组合漂浮物前方留 ≥1350 px：Z1 1120/220=5.09 s、Z2 1230/240=5.13 s、Z3 1350/260=5.19 s，
# 单角色最小尾端间距 900 px（Z1 4.09 s / Z2 4.25 s / Z3 3.85 s），都高于 3.5 s 基线。
const GROUPS := [
	# ---- Zone 1：教学。 ----
	{"group": "bird1", "zone": 1, "kind": "LOW_BIRD", "x": 1300.0, "w": 120.0},
	{"group": "rock1", "zone": 1, "kind": "SURFACE_ROCK", "x": 2400.0, "w": 110.0},
	{"group": "beam1", "zone": 1, "kind": "LOW_BEAM", "x": 3700.0, "w": 170.0},
	{"group": "rock2", "zone": 1, "kind": "SURFACE_ROCK", "x": 4900.0, "w": 140.0},
	{"group": "bird2", "zone": 1, "kind": "LOW_BIRD", "x": 6000.0, "w": 110.0},
	{"group": "shark1", "zone": 1, "kind": "SHARK", "x": 7200.0, "w": 70.0},
	{"group": "gate1", "zone": 1, "kind": "DIVE_GATE", "x": 8400.0, "w": 180.0},
	{"group": "beam2", "zone": 1, "kind": "LOW_BEAM", "x": 9600.0, "w": 180.0},
	# 高墙：SHIFT 跃起的下一课。跃起只把壳送进窗口，壳上的兔子撞墙楣，
	# 必须在空中把控制权交给兔子再按 ↑ 蹬踏（BRO OLLIE）。
	{"group": "wall1", "zone": 1, "kind": "HIGH_WALL", "x": 10800.0, "w": 30.0},
	{"group": "gate2", "zone": 1, "kind": "DIVE_GATE", "x": 12000.0, "w": 180.0},
	{"group": "log1", "zone": 1, "kind": "FLOATING_LOG", "x": 13300.0, "w": 32.0},
	{"group": "rock3", "zone": 1, "kind": "SURFACE_ROCK", "x": 14550.0, "w": 120.0},

	# ---- Zone 2：连换。 ----
	{"group": "beam3", "zone": 2, "kind": "LOW_BEAM", "x": 15800.0, "w": 170.0},
	{"group": "rock4", "zone": 2, "kind": "SURFACE_ROCK", "x": 17000.0, "w": 120.0},
	{"group": "shark3", "zone": 2, "kind": "SHARK", "x": 18200.0, "w": 70.0},
	{"group": "gate3", "zone": 2, "kind": "DIVE_GATE", "x": 19400.0, "w": 180.0},
	{"group": "bird3", "zone": 2, "kind": "LOW_BIRD", "x": 20600.0, "w": 120.0},
	{"group": "log2", "zone": 2, "kind": "FLOATING_LOG", "x": 21950.0, "w": 32.0},
	{"group": "rock5", "zone": 2, "kind": "SURFACE_ROCK", "x": 23200.0, "w": 130.0},
	{"group": "beam4", "zone": 2, "kind": "LOW_BEAM", "x": 24400.0, "w": 180.0},
	{"group": "wall2", "zone": 2, "kind": "HIGH_WALL", "x": 25600.0, "w": 30.0},
	{"group": "rock6", "zone": 2, "kind": "SURFACE_ROCK", "x": 26800.0, "w": 140.0},
	{"group": "gate4", "zone": 2, "kind": "DIVE_GATE", "x": 28000.0, "w": 180.0},
	{"group": "bird4", "zone": 2, "kind": "LOW_BIRD", "x": 29200.0, "w": 110.0},
	{"group": "log3", "zone": 2, "kind": "FLOATING_LOG", "x": 30550.0, "w": 32.0},
	{"group": "rock7", "zone": 2, "kind": "SURFACE_ROCK", "x": 31800.0, "w": 120.0},
	{"group": "beam5", "zone": 2, "kind": "LOW_BEAM", "x": 33000.0, "w": 170.0},
	{"group": "shark5", "zone": 2, "kind": "SHARK", "x": 34200.0, "w": 70.0},
	{"group": "bird5", "zone": 2, "kind": "LOW_BIRD", "x": 35400.0, "w": 120.0},
	{"group": "log4", "zone": 2, "kind": "FLOATING_LOG", "x": 36750.0, "w": 32.0},
	{"group": "gate5", "zone": 2, "kind": "DIVE_GATE", "x": 38000.0, "w": 180.0},

	# ---- Zone 3：收紧。 ----
	# 间距按“上一组尾端 +1000 px”（260 px/s = 3.85 s）排，组合前留 1350 px（5.19 s）。
	{"group": "shark6", "zone": 3, "kind": "SHARK", "x": 39200.0, "w": 70.0},
	{"group": "beam6", "zone": 3, "kind": "LOW_BEAM", "x": 40270.0, "w": 180.0},
	{"group": "rock8", "zone": 3, "kind": "SURFACE_ROCK", "x": 41450.0, "w": 130.0},
	{"group": "gate6", "zone": 3, "kind": "DIVE_GATE", "x": 42580.0, "w": 180.0},
	{"group": "log5", "zone": 3, "kind": "FLOATING_LOG", "x": 44110.0, "w": 32.0},
	{"group": "bird6", "zone": 3, "kind": "LOW_BIRD", "x": 45250.0, "w": 120.0},
	{"group": "wall3", "zone": 3, "kind": "HIGH_WALL", "x": 46370.0, "w": 30.0},
	{"group": "beam7", "zone": 3, "kind": "LOW_BEAM", "x": 47440.0, "w": 170.0},
	{"group": "rock9", "zone": 3, "kind": "SURFACE_ROCK", "x": 48610.0, "w": 140.0},
	{"group": "gate7", "zone": 3, "kind": "DIVE_GATE", "x": 49750.0, "w": 190.0},
	{"group": "log6", "zone": 3, "kind": "FLOATING_LOG", "x": 51290.0, "w": 32.0},
	{"group": "bird7", "zone": 3, "kind": "LOW_BIRD", "x": 52440.0, "w": 110.0},
	{"group": "shark8", "zone": 3, "kind": "SHARK", "x": 53550.0, "w": 70.0},
	{"group": "beam8", "zone": 3, "kind": "LOW_BEAM", "x": 54620.0, "w": 180.0},
	{"group": "rock10", "zone": 3, "kind": "SURFACE_ROCK", "x": 55800.0, "w": 120.0},
	{"group": "log7", "zone": 3, "kind": "FLOATING_LOG", "x": 57270.0, "w": 32.0},
	{"group": "bird8", "zone": 3, "kind": "LOW_BIRD", "x": 58410.0, "w": 130.0},
	{"group": "shark9", "zone": 3, "kind": "SHARK", "x": 59540.0, "w": 70.0},
	{"group": "beam9", "zone": 3, "kind": "LOW_BEAM", "x": 60610.0, "w": 170.0},
	{"group": "rock11", "zone": 3, "kind": "SURFACE_ROCK", "x": 61780.0, "w": 150.0},
	{"group": "gate8", "zone": 3, "kind": "DIVE_GATE", "x": 62930.0, "w": 180.0},
	{"group": "log8", "zone": 3, "kind": "FLOATING_LOG", "x": 64460.0, "w": 32.0},
	{"group": "bird9", "zone": 3, "kind": "LOW_BIRD", "x": 65600.0, "w": 120.0},
	{"group": "rock12", "zone": 3, "kind": "SURFACE_ROCK", "x": 66720.0, "w": 120.0},
]

# ---- 2026-11-11 补充指令：独立原型段 ----
# 五类障碍各一组，间距 1200 px（220 px/s = 5.45 s），保证“首次出现 ≥5 s”。
# 起点 x=400，第一组放在 1500，正好给满 PROMPT_RANGE=1100 的预警。
# 几何全部按“兔子层 / 乌龟层”两条路线设计，不按障碍名字派动作（数值为关卡空间，装载时 +34）：
#   LOW_BIRD   200～240：只压站立兔（218～266），趴低兔（250～274）与龟壳（272～328）都不碰
#   SURFACE_ROCK 220～262：只压兔子，龟壳顶 272 让开 10 px（实测兔子跳过去即可）
#   LOW_BEAM   140～240：站立兔顶头，趴低兔 250 起让开
#   DIVE_GATE  170～350：巡航龟壳顶 272 撞上沿；下潜 150 后兔头顶 368 让开 18 px
#   SHARK      240～335：巡航龟壳底 328 撞上；跃起 58 px 后龟壳底 270 让开
#   FLOATING_LOG 192～410：上沿压站立兔与跃起壳底，下沿压巡航龟壳；兔子跳上沿、乌龟潜下沿
const PROTO_GROUPS := [
	{"group": "proto_bird", "zone": 1, "kind": "LOW_BIRD",
		"rects": [Rect2(1500, 200, 120, 40)],
		"hint": "LOW BIRD", "action": "CROUCH DOWN",
		"lesson": "LOW BIRD - THE RABBIT CROUCHES"},
	{"group": "proto_rock", "zone": 1, "kind": "SURFACE_ROCK",
		"rects": [Rect2(2700, 220, 110, 42)],
		"hint": "LOW ROCK", "action": "JUMP OVER",
		"lesson": "JUMP THE ROCK - THE TURTLE PASSES UNDER"},
	{"group": "proto_beam", "zone": 1, "kind": "LOW_BEAM",
		"rects": [Rect2(3900, 140, 180, 100)],
		"hint": "DOCK BEAM", "action": "CROUCH DOWN",
		"lesson": "DOCK BEAM - CROUCH, THE SHELL KEEPS CRUISING"},
	{"group": "proto_gate", "zone": 1, "kind": "DIVE_GATE",
		"rects": [Rect2(5100, 170, 180, 180)],
		"hint": "REEF ARCH", "action": "TURTLE DIVE",
		"lesson": "REEF ARCH - TAKE THE TURTLE AND HOLD ↓"},
	{"group": "proto_shark", "zone": 1, "kind": "SHARK",
		"rects": [Rect2(6300, 240, 70, 206)],
		"hint": "SHARK", "action": "TURTLE LEAP",
		"lesson": "SHARK - TAKE THE TURTLE AND PRESS ↑"},
	{"group": "proto_log", "zone": 1, "kind": "FLOATING_LOG",
		"rects": [Rect2(7600, 158, 32, 218)],
		"hint": "FLOATING LOG", "action": "JUMP + DIVE",
		"lesson": "FLOATING LOG - JUMP, SWITCH, DIVE"},
	# BRO OLLIE：墙楣 world 120～136、窗口 world 136～240、墙身 world 240～520。
	# 跃起到顶（160）时龟心 174、壳 149～199（进窗口）、兔身 95～137（撞墙楣）；
	# 兔子蹬踏 +119 px 后身体 20～68，从墙楣顶上过去。数值为关卡空间（装载 +34）。
	# 墙宽 30：壳 90 宽，跃起高于墙身的窗口 168 px，扣除 120 px 落脚占位后
	# 仍有 ±24 px 起跳容错（BRO DIVE 的窗口也是 ~24 px）。墙楣下沿 136 是
	# “低跃从楣下钻过”的封口线：兔头顶 136 时壳底已低于墙身顶 240。
	{"group": "proto_wall", "zone": 1, "kind": "HIGH_WALL",
		"rects": [Rect2(9000, 86, 30, 16), Rect2(9000, 206, 30, 280)],
		"hint": "HIGH WALL", "action": "LEAP + KICK",
		"lesson": "HIGH WALL - LEAP, SWITCH, KICK"},
]
const PROTO_END := 10100.0

# 原型段里“组合障碍”的预期动作，测试和 F3 共用一份，避免两处各写一遍。
const ROLE_BY_KIND := {
	"LOW_BIRD": "RABBIT",
	"LOW_BEAM": "RABBIT",
	"SURFACE_ROCK": "RABBIT",
	"DIVE_GATE": "TURTLE",
	"SHARK": "TURTLE",
	"FLOATING_LOG": "BOTH",
	"HIGH_WALL": "BOTH",
}

const BOOST_LANES := [
	Rect2(2550, 250, 700, 70),
	Rect2(13700, 250, 700, 70),
	Rect2(18400, 250, 700, 70),
	Rect2(25800, 250, 700, 70),
	Rect2(33400, 250, 700, 70),
	Rect2(53000, 250, 500, 70),
	Rect2(54200, 250, 700, 70),
	Rect2(58900, 250, 500, 70),
	Rect2(62100, 250, 500, 70),
]


## 由“x + 宽度”生成完整组：判定框、F3 标签、教学文案共用同一份模板。
static func build_group(spec: Dictionary) -> Dictionary:
	var kind: String = spec["kind"]
	var shape: Dictionary = KIND_SPEC[kind]
	var w: float = spec.get("w", shape["w"])
	var rects := [Rect2(spec["x"], shape["y"], w, shape["h"])]
	# 高墙是两段矩形（墙楣 + 墙身），单矩形模板在这里不适用：
	# 中间 136～240 的窗口只放得下跃起到顶的壳（数值为关卡空间，装载时 +34）。
	if kind == "HIGH_WALL":
		rects = [Rect2(spec["x"], 86.0, w, 16.0),
			Rect2(spec["x"], 206.0, w, 280.0)]
	return {
		"group": spec["group"], "zone": spec["zone"], "kind": kind,
		"rects": rects,
		"hint": shape["hint"], "action": shape["action"],
		"lesson": shape["lesson"],
	}


static func groups() -> Array:
	var out := []
	for spec in GROUPS:
		out.append(build_group(spec))
	return out


static func proto_groups() -> Array:
	return PROTO_GROUPS.duplicate(true)


static func role_for_kind(kind: String) -> String:
	return ROLE_BY_KIND.get(kind, "RABBIT")


static func boost_lanes() -> Array:
	return BOOST_LANES.duplicate()


static func zone_at(x: float) -> Dictionary:
	for zone in ZONES:
		if x < zone["end"]:
			return zone
	return ZONES[ZONES.size() - 1]


static func zone_by_id(id: int) -> Dictionary:
	for zone in ZONES:
		if zone["id"] == id:
			return zone
	return ZONES[0]


static func groups_in_zone(id: int) -> Array:
	var result := []
	for spec in GROUPS:
		if spec["zone"] == id:
			result.append(build_group(spec))
	return result


static func lane_at(x: float) -> bool:
	for lane in BOOST_LANES:
		if x >= lane.position.x and x <= lane.end.x:
			return true
	return false


static func group_start(group: Dictionary) -> float:
	var start_x := 1.0e9
	for r in group["rects"]:
		var rect: Rect2 = r
		start_x = minf(start_x, rect.position.x)
	return start_x


static func group_end(group: Dictionary) -> float:
	var end_x := 0.0
	for r in group["rects"]:
		var rect: Rect2 = r
		end_x = maxf(end_x, rect.end.x)
	return end_x


## 供自检与报告使用的分区统计：组数、种类、连段簇、密度（组/分钟）。
static func stats() -> Dictionary:
	var result := {}
	for zone in ZONES:
		var zid: int = zone["id"]
		var list := groups_in_zone(zid)
		var kinds := {}
		var clusters := 0
		var largest := 1
		var run := 1
		var prev_x := -1.0e9
		var max_gap := 0.0
		var min_gap := 1.0e9
		for group in list:
			kinds[group["kind"]] = kinds.get(group["kind"], 0) + 1
			var gx := group_start(group)
			if prev_x > -1.0e8:
				var gap := gx - prev_x
				max_gap = maxf(max_gap, gap)
				min_gap = minf(min_gap, gap)
				if gap <= COMBO_GAP:
					run += 1
				else:
					if run >= 2:
						clusters += 1
						largest = maxi(largest, run)
					run = 1
			prev_x = gx
		if run >= 2:
			clusters += 1
			largest = maxi(largest, run)
		var seconds: float = (zone["end"] - zone["start"]) / zone["base_speed"]
		result[zid] = {
			"groups": list.size(),
			"kinds": kinds,
			"clusters": clusters,
			"largest_cluster": largest,
			"max_gap": max_gap,
			"min_gap": min_gap if min_gap < 1.0e8 else 0.0,
			"minutes": seconds / 60.0,
			"groups_per_min": list.size() / maxf(seconds / 60.0, 0.01),
		}
	return result
